import re
import subprocess
from flask import request
from flask import Flask
from flask import jsonify

app = Flask(__name__)


def get_build(value):
    result = value.communicate()
    builds_nums = re.findall('[0-9]{4}[0-9]*\.*[0]*\.*[0]*', str(result))
    builds_nums = set(builds_nums)
    builds_nums = sorted(builds_nums, reverse=True)
    builds = ','.join(e for e in builds_nums)
    builds = ["LATEST"] + builds.split(",")
    return builds


@app.route('/show_builds')
def show_builds():
    productversion = request.args.get('productversion')
    if productversion == "v6":
        package_name = "nlserver6"
    elif productversion == "v7":
        package_name = "nlserver6-v7"
    elif productversion == "acs":
        package_name = "nlserver7"
    else:
        package_name = "nlserver7"
    value = subprocess.Popen(['apt-cache', 'policy', package_name], stdout=subprocess.PIPE)
    return jsonify(get_build(value))


if __name__ == '__main__':
    app.run()


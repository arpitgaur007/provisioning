#!/usr/bin/python
""" Written by Christian Roue

 Description:

 Check response time for apache-nlmodule / nlserver-web-tomcat
 Optionnaly : allow restart of stuck instances

 Requires:

 Script has to be setuid root

"""

import os, sys, re
import StringIO,smtplib
from email.mime.text import MIMEText
from optparse import OptionParser
from datetime import datetime,timedelta
import httplib,socket
import time
import subprocess

# Nagios codes for ok to critical
NAGIOS_OK=0
NAGIOS_WARNING=1
NAGIOS_CRITICAL=2
NAGIOS_UNKNOWN=3

# Constants

# URLS to test Apache/Tomcat
APACHE_URL_TEST="/r/test"
TOMCAT_URL_TEST="/nl/jsp/logon.jsp"
TOMCAT_URL_TEST_NL7="/xtk/logon.jssp?ims=0"
PING_DB_URL="/nl/jsp/ping.jsp?__sessiontoken=monitoring/"

# String we should find in jsp output to consider page is ok
JSP_TOKEN_CHECK="login"

MAILFROM   = "nlcheck@neolane.net"
MAILTO     = "monitoring@neolane.net"
SMTPSERVER = "smtp"

# Time of restart - Avoid sending false alerts 6:00 -> 6:05
NL_SERVER_RESTART_HOUR=6
NL_SERVER_RESTART_MIN=5


# Whether we allow a server restart if detected as stuck
g_allow_component_restart=False


parser = OptionParser("usage %prog -w secs1 -c secs2 [-k]")
parser.add_option("-w",type="int",help="Seconds to get a web page before considering level is warning",default=5)
parser.add_option("-c",type="int",help="Seconds to get a web page before considering alert is critical",default=10)
parser.add_option("-k",action="store_true",dest="allow_restart",help="Allow probe to kill and restart apache or nlserver web")
parser.add_option("-v",action="store_true",dest="verbose",help="Detail probe actions")
parser.add_option("-e",type="string",help="Email address to send report to in case of a crash")
parser.add_option("-i",type="string",dest="log_path",help="interaction log path to check ")
parser.add_option("-d",type="string",help="Test Database health (ping.jsp) via this DNS")

def send_monitoring_email(subject):
    msg=MIMEText(s_io_verbose.getvalue())
    msg['Subject']=socket.gethostname()+" "+subject
    msg['From']=MAILFROM
    msg['To']=MAILTO
    s=smtplib.SMTP("smtp")
    try:
        s.sendmail(MAILFROM,[MAILTO],msg.as_string())
        s.quit()
    except e:
        print "Mail send failed",e
        pass

g_nl_version         = ""
g_nl_install_dir     = "/usr/local/neolane/"
g_nl_tomcat_url_test = TOMCAT_URL_TEST
# Hack until we allow short name in DNS Mask
g_nl_hostname        = os.popen("hostname").read().replace("\n","")

def nl_version():
    global g_nl_version
    global g_nl_install_dir
    global g_nl_tomcat_url_test
    # If already detected don't do it again
    if(g_nl_version):
        return g_nl_version
    p=os.popen("/usr/bin/dpkg -S nlserver")
    list=p.read()
    if "nlserver5" in list:
        g_nl_version="nl5"
        if g_verbose: print "Identified a Neolane version: 5"
    elif "ncs400" in list:
        g_nl_version="ncs400"
        if g_verbose: print "Identified a Neolane version: 4"
    elif "nlserver6" in list:
        g_nl_version = "nl6"
        if g_verbose:
            print "Identified a Neolane version: 6"
    elif "nlserver7" in list:
        g_nl_version = "nl7"
        g_nl_tomcat_url_test=TOMCAT_URL_TEST_NL7
        if g_verbose:
            print "Identified a Neolane version: ACS"
    g_nl_install_dir += g_nl_version
    if g_verbose:
        print "Identified version:",g_nl_version
        print " Installdir:",g_nl_install_dir
        print " FQDN      :",g_nl_hostname
        print " Apache URL:",APACHE_URL_TEST
        print " TOMCAT URL:",g_nl_tomcat_url_test
    return g_nl_version


def run_cmd_nlserver(options,get_output=True):
    """  execute nlserver <options> with the right neolane env  """
    nl_version()
    p=os.popen('/usr/bin/sudo -u neolane  bash -c ". %s/env.sh; nlserver %s"'%(g_nl_install_dir,options))
    if get_output:
        return p.read()
    else:
        return ""

def get_local_web_page(host,url,port,timeout):
    """ Retrieves a page at <url> on <host> wait maximum of <timeout> seconds
        returns (err_code,err_msg,time_elapsed,page_content)
    """
    if g_verbose:
        print "Retrieving page at URL:",url
    time_start = time.time()
    (err_code,err_string)=(NAGIOS_UNKNOWN,"unknown error")
    (time_elapsed,page_content)=(0,"")
    try:
        socket.setdefaulttimeout(timeout)
        conn = httplib.HTTPConnection(host,port)
        conn.request("GET", url)
        r = conn.getresponse()
        result=r.read()
        (err_code,err_string)=(NAGIOS_OK,"")
    except Exception, e:
        (err_code,err_string)=(NAGIOS_CRITICAL,"Read error:%s"%e)
        result=""
    time_elapsed=time.time()-time_start
    if g_verbose:
        print "Got HTML:",result
    return (err_code,err_string,time_elapsed,result)


# Capture logging in case of email notification
s_io_verbose=StringIO.StringIO()
def LogVerbose(msg):
    if g_verbose: print msg
    s_io_verbose.write(msg+"\r\n")


# Check who's connected
def users_connected():
    p=os.popen("/usr/bin/who")
    lst_who=p.read()
    return lst_who

def nlweb_pid():
    " Returns pid of 'nlserver web ...' 0 means not found"
    pdump_out=run_cmd_nlserver("pdump")
    pid=0
    # Identify pid of web
    re_web=re.compile(r"web.default .([0-9]+)..*")
    for i in pdump_out.splitlines():
        res=re_web.match(i)
        if res:
            pid=res.groups()[0]
            break
    return pid

def warn_users_connected(lst_users):
    ''' Report local users are connected to system so no restart can be done'''
    err_msg = " WARNING: Not restarting because of connected user\r\n"
    err_msg+=lst_users
    LogVerbose("Not restarting Apache because someone connected may be doing things on Neolane instance")
    LogVerbose(lst_users)
    return err_msg

def restart_apache():
    ''' Do a brute force restart of apache '''
    LogVerbose("Apache stuck, killing it.")
    p=os.popen("/usr/bin/killall -9 apache2")
    LogVerbose( p.read() )
    time.sleep(1)
    LogVerbose("Restarting apache.")
    p=os.popen("/etc/init.d/apache2 start")
    LogVerbose(p.read())

def restart_nl_web():
    ''' Kill restart nlserver web (Tomcat)'''
    pid=nlweb_pid()
    if pid>0:
        LogVerbose("nlserver web PID found:%s"%pid)
        LogVerbose("Killing and restarting nlserver web")
        p=os.popen("/bin/kill -9 "+pid)
    else:
        LogVerbose("Couldn't find pid will start again nlserver web anyway")
        run_cmd_nlserver("start web -noconsole",False)
        LogVerbose("nlserver web restarted.")


# Check log age
def check_log_age(process, filename, warn, critical):
    try:
        last_line = subprocess.check_output(['tail', '-1', filename])
        date_reg_exp = re.compile('(\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}).*')
        matches = date_reg_exp.search(last_line).group(1)
        dt_in_log = datetime.strptime(matches, '%Y-%m-%d %H:%M:%S')
    except Exception, e:
        ret_msg = " Check Age Read error:%s"%e
        ret_code = NAGIOS_CRITICAL
        return (ret_msg,ret_code)
    dt_current = datetime.now()
    if (dt_current - dt_in_log) < timedelta(minutes = warn):
        ret_msg = "%s OK."%process
        ret_code = NAGIOS_OK
    elif (dt_current - dt_in_log) > timedelta(minutes = warn) and (dt_current - dt_in_log) < timedelta(minutes = critical):
        ret_msg = "WARNING: %s."%process
        ret_code = NAGIOS_WARNING
    elif (dt_current - dt_in_log) > timedelta(minutes = critical):
        ret_msg = "CRITICAL: '%s' apparently stuck log too old!"%process
        ret_code = NAGIOS_CRITICAL
    else:
        ret_msg = "UNKNOWN: %s."%process
        ret_code = NAGIOS_UNKNOWN
    return (ret_msg, ret_code)


(options, args)=parser.parse_args()
if len(args) > 0:
    parser.error("No argument expected")
    sys.exit(NAGIOS_CRITICAL)

#Init globals
max_timeout=int(options.c)
warn_timeout=int(options.w)
g_allow_component_restart=options.allow_restart
g_verbose=options.verbose
g_email_notif=options.e
g_url_db_check=options.d

# Check if asked to kill on component deadlock and is run setuid root
if g_allow_component_restart and os.geteuid():
    print "WARNING: Not running setuid root can't restart apache / neolane. giving up"
    sys.stdout.flush()
    sys.exit(NAGIOS_WARNING)


# Forces nl version detection once
nl_version()

# First check apache is ok
(err_code,err_msg,elapsed,page)=get_local_web_page(g_nl_hostname,APACHE_URL_TEST,80,max_timeout)

if (err_code):
    err_msg="Apache is stuck!"
    if(g_allow_component_restart):
        lst_connected = users_connected()
        if lst_connected:
            err_msg += warn_users_connected(lst_connected)
        else:
            err_msg += " - restarted Apache. "
            restart_apache()
        if(g_email_notif):
            send_monitoring_email(err_msg)
else:
    # Apache is fine checking if it was slow to answer then check tomcat
    if elapsed > warn_timeout:
        (err_code,err_msg)=(NAGIOS_WARNING," Apache Warning (%.3ss). "%elapsed)
    else:
        err_msg=" Apache OK (%.3ss). "%elapsed

# Second check tomcat is ok
(err_code2,err_msg_tomcat,elapsed,page)=get_local_web_page("localhost",g_nl_tomcat_url_test,8080,max_timeout)
if (err_code2 or not JSP_TOKEN_CHECK in page):
    # Second chance , try using  FQDN
    (err_code2,err_msg_tomcat,elapsed,page)=get_local_web_page(g_nl_hostname,g_nl_tomcat_url_test,8080,max_timeout)
if (err_code2 or not JSP_TOKEN_CHECK in page):
    err_msg="NL Web is stuck! "
    if(g_allow_component_restart):
        lst_connected = users_connected()
        if lst_connected:
            err_msg += warn_users_connected(lst_connected)
        else:
            (hour,minute) = time.localtime(time.time())[3:5]
            if (hour == NL_SERVER_RESTART_HOUR and minute <= NL_SERVER_RESTART_MIN):
                err_msg += " WARNING: Not restarting NL Web restart time approx\r\n"
                LogVerbose("Not restarting WEB  because seems to be restart hour. Will be rechecked later.")
            else:
                err_msg += " - restarted"
                restart_nl_web()

# get most critical error as exit code
if err_code2 > err_code:
    err_code=err_code2
else:
    if elapsed > warn_timeout:
        (err_code,err_msg)=(NAGIOS_WARNING,err_msg+" NL Web warning (%.3ss). "%elapsed)
    elif err_code ==NAGIOS_OK:
        err_msg+=" NL Web OK (%.3ss). "%elapsed


if options.d and err_code < NAGIOS_CRITICAL:
    (err_code3,err_msg_tomcat,elapsed,page)=get_local_web_page(options.d,PING_DB_URL,8080,max_timeout)
    if (err_code3 or not "Ok" in page):
        err_msg="NL Web can't access DB ! "
        err_code=NAGIOS_CRITICAL
    elif err_code == NAGIOS_OK:
        err_msg+="Ping DB OK (%.3ss). "%elapsed

# Check interactiond logs if -i path was specified for interaction log
if options.log_path:
    (ret_msg,ret_code) = check_log_age("interactiond", options.log_path , 12, 15)
    err_msg+= ret_msg
    # if we are more critical than current report take precedenc
    if ret_code > err_code:
        err_msg=ret_msg
        err_code = ret_code

# Check missing processes
# Skip the first information line since with some custom builds, the build version includes a "@" causing false alters
# CRITICAL MISSING: 06:19:02 >   Application server for Adobe Campaign v7 (7.0 build 8891@435e8a1) of 02/09/2018
missing = ""
pdump_out = run_cmd_nlserver("monitor -missing | awk '{if (NR>1) print}'")
re_version = re.compile(r".*@.*")
for i in pdump_out.splitlines():
    res = re_version.match(i)
    if res:
        missing+= i+","

if missing:
    missing=missing[:-1]
    msg = "CRITICAL MISSING: %s"%missing
        # if ok/warning make our message the only important one.
    if err_code == NAGIOS_OK or err_code==NAGIOS_WARNING:
        err_msg=msg
    else:
       err_msg+=msg
    err_code = NAGIOS_CRITICAL
elif err_code==NAGIOS_OK:
    err_msg+="All processes running OK. "

if(g_email_notif):
    send_monitoring_email(err_msg)

# Send output and flush so it appears in Nagios text state
print err_msg
sys.stdout.flush()
sys.exit(err_code)

# vim: set ts=4 sw=4 foldenable foldmethod=indent

#!/usr/bin/env python

# library imports
import os
import argparse
from os import environ as ENV
from subprocess import check_output
import xml.etree.ElementTree as ET
import re
from soap import create_neo_records
from campaign_lib.custom_etcd import CampaignEtcd
import json

# pip imports
import click
import requests

# the domain name for all our campaign servers (they each get a subdomain
#   under this)
camp_domain = 'campaign.adobe.com'


class RegexMatchingParamType(click.ParamType):
    name = 'string'

    def __init__(self, regex_str):
        self.regex = re.compile('^' + regex_str + '$')
        self.regex_str = regex_str

    def convert(self, value, param, ctx):
        if self.regex.match(value):
            return value
        else:
            self.fail('given value "{}" did not match regex "{}"' \
                      .format(value, self.regex_str), param, ctx)


def neo(tenant_id, customer, entity, region, language, product_version, ticket, env_info, password):
    a = CampaignEtcd()
    tenant_id = tenant_id.lower()
    print env_info
    envinfo = json.loads(env_info)

    for key in envinfo:

        env_name = key.lower()
        env_type = envinfo[key].lower()
        if language == "fr-FR":
            lang = "French"
        else:
            lang = "English"
        num_instances = len(a.read(
            "datacenters/" + region + "/campaign/" + tenant_id + "/environments/" + key + "/servers/app")._children)
        camp_env = CampaignEnvironment(num_instances, tenant_id, env_type, env_name, customer, entity, language, product_version, ticket,
                                       password)
        for i in xrange(1, num_instances + 1):
            fqdn = camp_env.get_fqdn(i)
            if not is_reachable(fqdn):
                raise click.ClickException('{} was not reachable'.format(fqdn))
        camp_env.setup()
        click.echo("-------- Information --------")
        camp_env.print_info()
        out = camp_env.print_info()
        for i in xrange(1, num_instances + 1):
            # camp_env.print_host_info(i, out)
            out = camp_env.print_host_info(i, out)
        message = create_neo_records(**out)
        print message


class CampaignEnvironment:
    def __init__(self, num_instances, tenant_id, env_type, env_name, customer, entity, lang, version, ticketnum, password):
        self.num_instances = num_instances
        self.tenant_id = tenant_id
        self.env_type = env_type
        self.env_name = env_name
        self.customer = customer
        self.entity = entity
        self.lang = lang
        self.password = password
        self.insversion = version
        self.jira = ticketnum

        # convenient derived values
        self.fullname = '-'.join([tenant_id, env_type, env_name])
        env_name_tmp = re.match('([^0-9]+)[0-9]+', env_name).group(1)
        self.email = '{}-{}-{}@{}'.format(tenant_id, env_type, env_name_tmp, camp_domain)

    def setup(self):
        click.echo('determining campaign version... ', nl=False)
        self.version = self.get_version()
        click.echo('(version {})'.format(self.version))
        self.instance_name = self.get_instance_name()
        self.config = self.get_config()
        return self

    def print_info(self):

        output = {"neo_server": "neo.neolane.net",
                  "neo_login": "automation",
                  "neo_password": self.password,
                  "adobeEntity": self.entity,
                  "language": self.lang,
                  "customerName": self.customer}

        creds = map(str.strip, self.get_creds())
        creds_track = map(str.strip, self.get_tracking_creds())
        get_attrib = lambda xpath, name: \
            self.config.find(xpath + '[@{}]'.format(name)).attrib[name]
        conf_attributes = {
            'database_creds': get_attrib('.//dbcnx/', 'login').replace(':', ',').split(","),
            'database_id': '' if self.env_type == 'mid' else get_attrib('.//web/redirection/', 'databaseId'),
            'database_hostname': get_attrib('.//dbcnx/', 'server'),
        }
        output['envs'] = {
            self.tenant_id + '-' + self.env_type + '-' + self.env_name: {"databaseId": conf_attributes['database_id'],
                                                                         "version": self.insversion,
                                                                         "serverURL": 'https://{}'.format(
                                                                             self.get_fqdn()),
                                                                         "dbAccount": conf_attributes['database_creds'][
                                                                             1],
                                                                         "dbName": conf_attributes['database_creds'][0],
                                                                         "dbPassword": self.get_db_pw(),
                                                                         "dbServer": conf_attributes[
                                                                             'database_hostname'],
                                                                         "dbServerURL": conf_attributes[
                                                                             'database_hostname'],
                                                                         "comments": '%s: %s\n%s: %s' % (
                                                                             creds_track[0], creds_track[1], creds[0],
                                                                             creds[1]),
                                                                         "jira": self.jira

                                                                         }}
        output['envs'][self.tenant_id + '-' + self.env_type + '-' + self.env_name]['app_servers'] = dict()
        return output

    def get_creds(self):
        path = '{}/password/campaign/{}'.format(ENV['HOME'], self.tenant_id)
        if not os.path.isdir(path):
            path = '{}/password/campaign/{}'.format(ENV['HOME'], self.fullname)
        if self.env_type == 'mkt':
            creds = ['sftp', '{} {}'.format(self.tenant_id[0:30], read_if_exists(path + '/sftp'))]
        if self.env_type == 'mid':
            creds = ['mid', 'prod {}'.format(read_if_exists(path + '/prod'))]
        if self.env_type == 'rt':
            creds = ['mc', 'mc {}'.format(read_if_exists(path + '/mc'))]
        creds[0] += ' creds'
        #	creds[1] = creds = ['tracking', '{}'.format(read_if_exists(path + '/tracking'))]
        if creds[1] is None:
            creds[1] = ''
        return creds

    def get_tracking_creds(self):
        path = '{}/password/campaign/{}'.format(ENV['HOME'], self.tenant_id)
        if not os.path.isdir(path):
            path = '{}/password/campaign/{}'.format(ENV['HOME'], self.fullname)
        creds = ['tracking', '{}'.format(read_if_exists(path + '/tracking'))]
        creds[0] += ' creds'
        if creds[1] is None:
            creds[1] = ''
        return creds

    def print_host_info(self, i, output):
        processes = self.get_processes(i)
        if 'mta' in processes:
            mta = True
        else:
            mta = False
        if 'wfserver' in processes:
            wfserver = True
        else:
            wfserver = False
        if 'web' in processes:
            web = True
        else:
            web = False
        if 'sms' in processes:
            sms = True
        else:
            sms = False
        if 'inmail' in processes:
            inmail = true
        else:
            inmail = False
        output['envs'][self.tenant_id + '-' + self.env_type + '-' + self.env_name]['app_servers'][
            self.tenant_id + '-' + self.env_type + '-' + self.env_name + '-' + str(i)] = {"serverURL": self.get_fqdn(i),
                                                                                          "internalURL": 'http://{}'.format(
                                                                                              self.get_ip(i)),
                                                                                          "externalURL": self.fullname + '-t.adobe-campaign.com',
                                                                                          "activeMTA": mta,
                                                                                          "activeSMS": sms,
                                                                                          "activeWeb": web,
                                                                                          "activeWf": wfserver,
                                                                                          "activeInMail": inmail
                                                                                          }
        return output

    def get_fqdn(self, i=None):
        if i is None:
            if self.env_name == 'prod1':
                return '{}.{}'.format(self.tenant_id, camp_domain)
            return '{}.{}'.format(self.fullname, camp_domain)
        return '{}-{}.{}'.format(self.fullname, i, camp_domain)

    def get_tracking_url(self):
        return '{}-t.{}'.format(self.fullname, camp_domain)

    def get_email(self):
        env_name_tmp = re.match('([^0-9]+)[0-9]+', self.env_name).group(1)
        email = '{}-{}-{}@{}'.format(
            self.tenant_id, self.env_type
            , env_name_tmp, camp_domain)
        return email

    # gets the private IP address of the instance
    def get_ip(self, i):
        fqdn = self.get_fqdn(i)
        return check_output('|'.join([
            'ssh 2>/dev/null "{}" ip addr show eth0 scope global'.format(fqdn)
            , "sed 's/  */ /g'", 'grep inet'
            , "cut -d' ' -f3", 'cut -d/ -f1'
        ]), shell=True)

    # purpose: gets the list of names of nlserver processes running on the
    #           instance, sans watchdog and syslogd
    def get_processes(self, i):
        fqdn = self.get_fqdn(i)
        ignored = ['watchdog', 'syslogd']
        processes = check_output('|'.join([
            'ssh 2>/dev/null "{}" pgrep -a nlserver'.format(fqdn)
            , "cut -f3 -d' '"
        ]), shell=True).split('\n')
        return [proc for proc in processes if proc not in ignored]

    def get_admin_pw(self):
        paths = [
            '{}/password/campaign/{}/admin'.format(ENV['HOME'], self.instance_name)
            , '{}/password/campaign/{}/admin'.format(ENV['HOME'], self.fullname)
        ]
        for path in paths:
            result = read_if_exists(path)
            if result is not None:
                return result
        return None

    def get_db_pw(self):
        path = '{}/password/postgresql/{}{}{}/postgres'.format(
            ENV['HOME'], self.tenant_id, self.env_type, self.env_name)
        return read_if_exists(path)

    # purpose: returns the contents of the config-<instance>.xml file associated
    #           with the instance
    def get_config(self, i=None):
        conf_dir = "/usr/local/neolane/nl{}/conf".format(self.version)
        raw_contents = check_output(
            'ssh 2>/dev/null "{}"'.format(self.get_fqdn(i)) +
            ' cat "{}/config-{}.xml"'.format(conf_dir, self.instance_name)
            , shell=True).strip()
        return ET.fromstring(raw_contents)

    # purpose: gets the actual name of the instance, as indicated by the name
    #           of its config file. This is important because the tenant ID
    #           may be truncated.
    def get_instance_name(self, i=None):
        fqdn = self.get_fqdn(i)
        text = requests.get('https://{}/r/test'.format(fqdn)).text
        return re.match(".* instance='([^']+)' .*", text).group(1)

    # purpose: gets the version of nlserver installed on a host by checking
    #           the dirs present in /usr/local/neolane/
    def get_version(self, i=None):
        version_strings = check_output('|'.join([
            'ssh 2>/dev/null {} '.format(self.get_fqdn(i)) +
            'find /usr/local/neolane -type d -mindepth 1 -maxdepth 1 -name nl[67]'
            , 'xargs -n 1 -I% basename %', "sed 's/nl//g'"
        ]), shell=True).split('\n')
        versions = [int(s) for s in version_strings if s != '']
        if len(versions) != 1:
            raise Exception('got campaign versions'.format(versions))
        elif versions[0] not in [6, 7]:
            raise Exception('unknown campaign version'.format(versions[0]))
        else:
            return versions[0]


def is_reachable(hostname):
    click.echo("testing connectivity to {}...".format(hostname))
    try:
        check_output('ssh 2>/dev/null "{}" echo'.format(hostname), shell=True)
    except Exception as e:
        click.echo(e, err=True)
        return False
    return True


def read_if_exists(path):
    try:
        with open(path, 'r') as f:
            return f.read()
    except Exception as e:
        print str(e)
        pass
    return None


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("tenant_id", help="Tenant ID")
    parser.add_argument("customer", help="Customer Name")
    parser.add_argument("entity", help="Adobe Entity ADUS/ADIR")
    parser.add_argument("region", help="Region")
    parser.add_argument("language", help="English/French")
    parser.add_argument("product_version", help="Product Version. Eg:- Classic-Mid, ACS")
    parser.add_argument("ticket", help="Jira Ticket Number")
    parser.add_argument("env_info", help="Dictionaries of environments")
    parser.add_argument("password", help="Neo Automation Password")
    args = parser.parse_args()
    env_info = str(args.env_info)
    if "\'" in args.env_info:
        env_info = str(args.env_info).replace("\'", "\"")

    neo(args.tenant_id, args.customer, args.entity, args.region, args.language, args.product_version, args.ticket, env_info, args.password)
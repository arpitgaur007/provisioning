function getRulesetId (rulesetName) {
  var query = NLWS.xtkQueryDef.create(
  {queryDef: {schema: "nms:ruleSet", operation: "select",
    select: {
        node: [{expr: "@active"}, {expr: "@name"}, {expr: "@id"}]
    },
    where: {
      condition: [{expr: "[@name] = '" + rulesetName + "'" }]
    }
  }})

  var res = query.ExecuteQuery()
  //logInfo('res=' + JSON.stringify(res));


  var ruleSet = res.getElementsByTagName("ruleSet")
  var id = ""
  for each (var r in ruleSet) {
    logInfo("Present ruleset state:  name=" + r.getAttribute("name") + " id=" + r.getAttribute("id") + " active=" + r.getAttribute("active"))
    id = r.getAttribute("id")
  }
  return id
}

var id = getRulesetId('defaultDomains')
if (id && id > 0) {
  xtk.session.Write(<ruleSet _operation="update" active="false" id={id} name="defaultDomains" xtkschema="nms:ruleSet"/> )
  logInfo("Disabling ruleset: active => fase")
  getRulesetId('defaultDomains')
} else {
  logInfo("Failed to get ruleSet id. Update failed!")
}

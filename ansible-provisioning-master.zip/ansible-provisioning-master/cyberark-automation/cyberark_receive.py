from __future__ import print_function
from Crypto.PublicKey import RSA
import base64
import boto3

private_key_path = 'private_key.pem'

def datadecrypt(keypath, message):

    with open(keypath,'r') as file:
        private_key = file.read()
    file.close()

    key = RSA.importKey(private_key)

    decoded_encrypted_msg = base64.b64decode(message)
    decoded_decrypted_msg = key.decrypt(decoded_encrypted_msg)
    return decoded_decrypted_msg


def recieve_sqs_data():


    # Create SQS client
    sqs = boto3.client('sqs', region_name='ap-south-1')

    queue_url = 'https://sqs.ap-south-1.amazonaws.com/483013340174/cyberarkdata'

    # Receive message from SQS queue
    response = sqs.receive_message(
        QueueUrl=queue_url,
        AttributeNames=[
            'SentTimestamp'
        ],
        MaxNumberOfMessages=1,
        MessageAttributeNames=[
            'All'
        ],
        VisibilityTimeout=0,
        WaitTimeSeconds=0
    )

    try:
        message = response['Messages'][0]
        receipt_handle = message['ReceiptHandle']

        # Delete received message from queue
        sqs.delete_message(
            QueueUrl=queue_url,
            ReceiptHandle=receipt_handle
        )

        data = dict()

        for key, value in message['MessageAttributes'].iteritems():

            data[key] = datadecrypt(private_key_path, value['StringValue'])


        return data
    except Exception as e:
        print('No data in sqs.')


if __name__ == "__main__":
    data = recieve_sqs_data()

#!/usr/bin/env python

import requests
import logging
from ansible.module_utils.basic import *

class DelivInstance():
    """Class to Interact with Deliverability Instnace API"""

    # URLs
    url = 'https://deliverability-app.neolane.net/deliverability'
    url_login = url + '/login'
    url_acct = url + '/accountConfiguration'
    url_providers = url + '/inboxrendering/providers'
    url_insert_user = url + '/administration/users/insertUser'
    url_seed_list = url + '/inboxrendering/seedlist'

    def __init__(self, module):
        self.login(module)

    # Login to the application - get JSESSIONID
    def login(self, module):
        data = {
            'username': module.params.get('master_username', None),
            'password': module.params.get('master_password', None),
            'force': 'true',
        }
        self.session = requests.Session()
        self.session.post(self.url_login, data=data, allow_redirects=False)
        return True

    # HTTP POST wrapper
    def http_post(self, url, cont_type, data):
        headers = {
            'Content-Type': 'application/json',
        }
        if cont_type:
            headers['Content-Type'] = cont_type

        if headers['Content-Type'] == 'application/json':
            return self.session.post(url, json=data, headers=headers)

        return self.session.post(url, data=data, headers=headers, allow_redirects=False)

    # HTTP GET wrapper
    def http_get(self, url):
        headers = {}
        return self.session.get(url, headers=headers, allow_redirects=False)

    def new_user(self, module):

        roles = {
            'ADMINISTRATOR': '101role',
            'ONLOOKER': '102role',
            'INBOXRENDERING': '103role',
        }

        role_id = roles[module.params.get('role', None)]
        if not role_id:
            module.fail_json(msg="user role '" + module.params.get('role', None) + "' is not valid")
        data = {
            'firstName': module.params.get('username', None),
            'lastName': module.params.get('lastname', None),
            'email': module.params.get('email', None),
            'password': module.params.get('password', None),
            'role': role_id,
        }
        r = self.http_post(self.url_insert_user, 'application/x-www-form-urlencoded', data=data)
        return r.status_code

    # fetch acount info given CUID
    def acct_get(self, cuid):
        self.acct = RenderingAcct()
        r = self.http_get(self.url_acct + '/' + cuid)
        data = r.json()
        # load up acct if exists
        if data:
            self.acct.load(data[0])
            return self.acct
        # return false when account not found
        return False

    def get_providers(self):
        r = self.http_get(self.url_providers)
        return r.text

    # create Litmus Provider for CUID
    def create_litmus_prov(self, cuid):
        self.acct = RenderingAcct()
        self.acct.new(cuid)
        r = self.http_post(self.url_acct, False, data=self.acct.data)
        self.acct = RenderingAcct()
        self.acct.load(r.json())
        return self.acct

    # return a json object containing Litmus seeds
    def get_seed_list(self):
        # r = self.http_post(self.url_seed_list, False, data={})
        r = self.http_get(self.url_seed_list)
        return r.json()


class RenderingAcct():
    """Class representing Inbox Rendering Cccount"""

    def __init__(self):
        self.data = {}

    # load up json response as
    def load(self, data):
        self.data = data

    def new(self, cuid):
        data = {
            "accountId": "cuid",
            "providerId": "101provider",
            "providerUsername": "tuw3fmf9320fmf3",
            "providerPassword": "woiweowcwoiefweockweco",
            "defaultProvider": 'true',
            "useDefaultCredentials": 'true',
            "overrideCommonDevices": 'true',
            "status": 1,
            "version": 1
        }
        data["accountId"] = cuid
        self.load(data)
        return self

    def get_attr(self, attr):
        return self.data[attr]

def main():

    fields = {
        "username": {"required": True, "type": "str"},
        "email": {"required": True, "type": "str"},
        "cuid": {"required": True, "type": "str"},
        "password": {"required": True, "type": "str"},
        "master_username": {"required": True, "type": "str"},
        "master_password": {"required": True, "type": "str"},
        "role": {"required": True, "type": "str"},
        "lastname": {"required": True, "type": "str"}
    }
    module = AnsibleModule(argument_spec=fields)
    di = DelivInstance(module)
    acct = di.acct_get(module.params.get('cuid',None))
    if not acct:
        acct = di.create_litmus_prov(module.params.get('cuid',None))
        if not acct.data:
            module.fail_json(msg="Failed to create provider for cuid %s" % module.params.get('cuid',None), meta=acct)
    status=di.new_user(module)
    module.exit_json(changed=True, msg="Litmus provider and user account for " + module.params.get('email', None) + " setup up.", meta={ 'status': status })

if __name__ == '__main__':
    main()

import MySQLdb
import argparse
import ipaddress
import sys
import os

DATABASE_IP = "provisioningworker.chgnf24yggfh.eu-west-1.rds.amazonaws.com"
DB_USER = "provworker"
DB_PASSWORD = os.environ['IP_DB_PASSWORD']
DATABASE = "smtpips"


def add_smtp_ips(subnet, geo, IPtype):

    try:
        db = MySQLdb.connect(DATABASE_IP, DB_USER, DB_PASSWORD, DATABASE)
        cursor = db.cursor()
    except Exception as e:
        print(e)
        sys.exit(1)

    try:
        ips = ipaddress.ip_network(unicode(subnet))
        for ip in ips:
            if ipaddress.IPv4Address(ip).is_global:
                sql = "insert into %s (ip,tenant,type) values ('%s','','%s');" % (geo, ip, IPtype)
                cursor.execute(sql)
            else:
                print("Only Global IP addresses are allowed")
                sys.exit(1)
        db.commit()
        print("IPs added into the database.")

    except ValueError:
        print("%s doesn't appear to be a valid IP4 network." % subnet)


if __name__=="__main__":
    geos = ['us', 'apac', 'emea']
    parser = argparse.ArgumentParser()
    parser.add_argument("subnet", help="IP subnet to add into DB")
    parser.add_argument("geo", help="IP subnet GEO. us/apac/eu")
    parser.add_argument("IPtype", help="IP Type. Whether momentum/nlproxy?")
    args = parser.parse_args()
    if args.geo in geos:
        add_smtp_ips(args.subnet, args.geo, args.IPtype)
    else:
        print("Geo should be one of the following. us/apac/emea")
        sys.exit(1)
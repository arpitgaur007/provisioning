var doc = DOMDocument.load('/tmp/defaultDataSource.xml');

NLWS.xtkSession.Write({
  amcDataSource: {
    xtkschema: "nms:amcDataSource",
    name: doc.root.$name,
    dataSourceId: doc.root.$dataSourceId,
    destinationId: doc.root.$destinationId,
    targetResource: doc.root.$targetResource,
    targetSchema: doc.root.$targetSchema,
    targetField: doc.root.$targetField,
    hashAlgorithm: doc.root.$hashAlgorithm
  }
});
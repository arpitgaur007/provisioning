#!/usr/bin/env bash
echo "127.0.0.1 ansible_python_interpreter=`which python`" > inventory/localhost
/usr/bin/env pip install -U -r requirements.txt
./sync_submodules.sh
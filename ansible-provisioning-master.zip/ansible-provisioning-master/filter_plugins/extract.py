import types

def extract(var, **kwargs):
    attr = kwargs.get('attribute', None)
    if attr is None:
        return var
    if not isinstance(var, dict):
        return var
    res = []
    for k, v in var.items():
        res.append(v[attr])
    return res

class FilterModule(object):

    def filters(self):
        return {
            'extract_custom': extract
        }

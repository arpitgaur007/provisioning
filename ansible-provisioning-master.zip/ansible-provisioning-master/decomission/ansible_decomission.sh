#!/bin/bash

ansible-playbook -i inventory/localhost --extra-vars="$1" playbooks/campaign/cleanup_campaign_ec2.yml

if [[ $? == 0 ]]; then
    curl -s -X POST --data-urlencode "payload={'channel': '#camp-rundeck', 'username': 'deploy', \
    'attachments': [{ 'color': '#36a64f','title': 'Decomissioning', \
    'text': '$2 $3 decomissioned'}]}" \
     https://hooks.slack.com/services/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
    exit 0
fi;
exit 1

var c = REST.head.imsConfig.get();
REST.head.imsConfig.patch({
  cauiURL: c.cauiURL.match(/stage/) ? "https://stage.aedash.adobe.com" : "https://adminconsole.adobe.com"
});

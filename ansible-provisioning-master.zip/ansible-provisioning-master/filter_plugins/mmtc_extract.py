from ansible import errors
import re
import json
import os


def extract_mmtc_info(output):
    cluster_info = []
    handle = ""
    cluster_regex = re.compile("\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}[ ]+:[ ]+([a-z1-9\-]+)")
    handle_regex = re.compile("outbound-ips-api\.camp-infra\.adobe\.net\/api\/momentum\/register\/([a-z0-9\-\/]+)")
    for line in output.split('\n'):
        match = cluster_regex.search(line)
        if match:
            cluster_info.append(match.group(1))
        hmatch = handle_regex.search(line)
        if hmatch:
            handle = hmatch.group(1)
    return {
        "cluster": list(set(cluster_info)),
        "handle": handle
    }


class MDP_PASS:
    def __init__(self, file_path):
        self.mdp = file_path

    def decode_data(self, string):
        key = os.environ.get('MDP_SECRET_KEY')
        if not key:
            raise Exception("Please specify MDP_SECRET_KEY in environment variable.")
        encoded_chars = []
        for i in range(len(string)):
            key_c = key[i % len(key)]
            encoded_c = chr((ord(string[i]) - ord(key_c) + 256) % 256)
            encoded_chars.append(encoded_c)
        encoded_string = ''.join(encoded_chars)
        return encoded_string

    def extract_password(self, instance):
        with open(self.mdp) as f:
            dec_data = self.decode_data(f.read())
            data = json.loads(dec_data)
        # import pdb;pdb.set_trace()
        try:
            return data[instance].split()[1]
        except Exception, e:
            print('This instance doesnt have any entry in mdp.')
            return ""


def extract_campaign_password(instance_name):
    try:
        mdp_file = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'pass_enc')
        obj = MDP_PASS(mdp_file)
        return obj.extract_password(instance_name)
    except Exception, e:
        print "Trying only ACC migration"
        return ""


class FilterModule(object):
    def filters(self):
        return {
            'extract_mmtc_info': extract_mmtc_info,
            'extract_campaign_password': extract_campaign_password
        }

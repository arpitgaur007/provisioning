#!/usr/bin/python

from ansible.module_utils.basic import *
from deliverability_lib.soap import DeliverabilitySoapSession
from deliverability_lib.fields import DeliverabilityEntry, Hosting, Bundle, Region
from deliverability_lib.exceptions import DuplicateEntryException, DeliverabilityException

DOCUMENTATION = '''
---
module: momentum

short_description: CUID generation during provisioning

version_added: "1.0"

description:
    - "Module to create CUID on deliverability instance"

options:
    name:
        description:
            - This is tenant name 
        required: true
    tenant_env:
        description:
            - This is tenant Environment
        required: true
    dlv_user:
        description:
            - Deliverability User Id 
        required: true
    dlv_pass:
        description:
            - Deliverability User Password 
        required: true
'''

EXAMPLES = '''
- name: CUID generation
  momentum:
    name: sachsharops
    tenant_env: prod1
    dlv_user: testuser 
    dlv_pass: testpass
'''

RETURN = '''
original_message:
    description: The original name param that was passed in
    type: str
message:
    description: The output message that the sample module generates
'''


class MomentumEntry(object):
    deliverability_url = "deliverability.neolane.net"

    def __init__(self, dlv_user, dlv_pwd):
        self.dlv_user = dlv_user
        self.dlv_pwd = dlv_pwd

    def generate_cuid(self, tenant_name, tenant_env, ip_list):
        entry_name = '%s %s (automated)' % (tenant_name, tenant_env)
        domain = ''
        ip_domain = ''
        dkim_selector = tenant_name
        comment = '''Automated generated using momentum module from Ansible Provisioning'''
        entry = DeliverabilityEntry(entry_name, Hosting.hosted,
                                    Bundle.standard, Region.EMEA,
                                    dkim_selector, ip_list,
                                    domain, ip_domain, comment=comment
                                    )
        session = DeliverabilitySoapSession(self.deliverability_url)
        # errors can be thrown if:
        #   - the network fails,
        #   - the SOAP call response contains an error message, or
        #   - something in the response is contradictory
        try:
            session.login(self.dlv_user, self.dlv_pwd)
            # the CUID is just a string. It's what you use to identify the deliverability entry.
            entry = session.create_entry(entry)
        except DuplicateEntryException:
            # TODO -- should probably try reading the existing entry and using that CUID down the road.
            # print('An entry already exists with name "%s"' % (self.tenant_name))
            return False, 'An entry already exists with name "%s"' % (self.tenant_name)
        except DeliverabilityException, e:
            # print('[%s] Received unknown deliverability exception "%s"' % (self.tenant_name, repr(e.message)))
            return False, '[%s] Received unknown deliverability exception "%s"' % (self.tenant_name, repr(e.message))
        finally:
            session.logout()
        return True, entry.cuid


def run_module():
    # define the available arguments/parameters that a user can pass to
    # the module
    module_args = {
        'tenant_name': {'type': 'str', 'required': True},
        'tenant_env': {'type': 'str', 'required': True},
        'ip_list': {'type': 'list', 'required': True},
        'dlv_user': {'type': 'str', 'required': True},
        'dlv_pwd': {'type': 'str', 'required': True}
    }
    result = dict(
        name='',
        cuid='',
        msg=''
    )
    module = AnsibleModule(argument_spec=module_args)
    mo_obj = MomentumEntry(module.params['dlv_user'], module.params['dlv_pwd'])
    tenant_name = module.params['tenant_name']
    tenant_env = module.params['tenant_env']
    ip_list = module.params['ip_list']
    status, message = mo_obj.generate_cuid(tenant_name, tenant_env, ip_list)
    if status:
        result['cuid'] = message
        result['msg'] = 'CUID creation success'
    else:
        result['msg'] = "message"
        module.fail_json(**result)
    module.exit_json(changed=True, ansible_facts=dict(deliverability_id=result['cuid']), msg=result['msg'])


def main():
    run_module()


if __name__ == '__main__':
    main()

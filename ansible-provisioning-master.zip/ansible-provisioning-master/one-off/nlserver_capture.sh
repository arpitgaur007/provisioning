#!/usr/bin/env bash

# Description: A custom Bash script for Campaign NLServer Core & Stack Trace Capture
# Use this script to capture information needed by Engineering in case when a Campaign
# process is frozen or consumes too much CPU/Memory

# Usage (as root): ./nlserver_capture.sh [nlserver process name]

set -eo pipefail

if [ $# -ne 1 ]; then
        echo -e "\nUsage Error: ./nlserver_capture.sh [nlserver process name]"
        echo -e "Example: ./nlserver_capture.sh [web | mta | wfserver | sms ]\n"
        exit 1
fi

# Declare Variables
NLPROCESS_PID=$(pgrep -f 'nlserver '$1)
OUTPUT_DIR=/tmp/$(hostname -s)
DATE=$(date +%d%b%Y_%H%M%S)
mkdir -p $OUTPUT_DIR

function chk_root() {

	if [[ $USER != 'root' ]]; then
		echo -e "You must be logged in as 'root' user to run this tool!"
		exit 999
	fi

}

function write_header() {

        echo -e "#######################################################################################################################################################################################"
        echo -e "                                                                  #####  $1  #####"
        echo -e "#######################################################################################################################################################################################"

}

function system_summary() {
        
        write_header " Host System information "
        echo "Hostname : $(hostname -s)"
        echo "Fully qualified domain name : $(hostname -f)"
        echo "Network address (IP) :  $(hostname -i)"
        echo "Public address (IP) : $(curl -s ip.neolane.net | xargs echo -n)"
        echo 'Up Since:' $(date -d "`cut -f1 -d. /proc/uptime` seconds ago")
        echo 'Duration:' $(uptime | awk -F'( |,|:)+' '{print int($6/7),"weeks",$8,"hours,",$9,"minutes."}')
        echo
        df -h

        write_header " Hardware and OS information"
        lshw -short 2>/dev/null ||
        dmidecode -t 1,0 | grep -E 'Manufacturer|Product|Serial|Release|Version' | sort -k 1 | uniq |  cut -f2
        echo "Operating system : $(uname)"
        lsb_release -a 2>/dev/null || true

        write_header " CPU information"
        lscpu | grep -E '^Thread|^Core|^Socket|^CPU\(|^CPU M'
        echo
        top -b -n1 | head -n 3
        echo -e "\nCPU Usage: $(top -bn1 | grep "Cpu(s)" | sed "s/.*, *\([0-9.]*\)%* id.*/\1/" | awk '{print 100 - $1"%"}')\n"
        echo -e "Top 10 CPU consuming process:"
        ps -Ao user,pid,pcpu,comm --sort=-pcpu | head -n 10

        write_header " Memory information "
        echo "Free and used memory:"
        free -m
        echo
        free -m | awk 'NR==2{printf "Memory Usage: %s/%sMB (%.2f%%)\n", $3,$2,$3*100/$2 }'
        echo

        echo "Top 10 Memory consuming process:"
        ps auxf | sort -r -k 4 | head -n 10

} 

function nlserver_dump_info() {

        su neolane -c "source /usr/local/neolane/nl*/env.sh && nlserver pdump -full" > $OUTPUT_DIR/pdump.txt

        write_header " Generating Core Dump"
        gcore -o $OUTPUT_DIR/core $NLPROCESS_PID

        gdb -q -n -ex "thread apply all bt" -batch /usr/local/neolane/nl*/bin/nlserver $NLPROCESS_PID >> $OUTPUT_DIR/pstack.1.txt
        gdb -q -n -ex "thread apply all bt" -batch /usr/local/neolane/nl*/bin/nlserver $NLPROCESS_PID >> $OUTPUT_DIR/pstack.2.txt
        gdb -q -n -ex "thread apply all bt" -batch /usr/local/neolane/nl*/bin/nlserver $NLPROCESS_PID >> $OUTPUT_DIR/pstack.3.txt
        gdb -q -n -ex "thread apply all bt" -batch /usr/local/neolane/nl*/bin/nlserver $NLPROCESS_PID >> $OUTPUT_DIR/pstack.4.txt
        gdb -q -n -ex "thread apply all bt" -batch /usr/local/neolane/nl*/bin/nlserver $NLPROCESS_PID >> $OUTPUT_DIR/pstack.5.txt

        write_header " Capturing System Calls"
        timeout --preserve-status 10 strace -vvfttp $NLPROCESS_PID -s1024 -o $OUTPUT_DIR/strace.txt
        timeout --preserve-status 10 strace -fcp $NLPROCESS_PID -o $OUTPUT_DIR/syscalls_report.txt

}

main() {

  chk_root
  system_summary | tee -a $OUTPUT_DIR/system_summary.txt || true
  nlserver_dump_info

  #Packaging nlserver On-Demand Capture
  tar cfvz $TARBALL_FULLPATH.tar.gz -C $OUTPUT_DIR .
  rm -rf $OUTPUT_DIR

}

main

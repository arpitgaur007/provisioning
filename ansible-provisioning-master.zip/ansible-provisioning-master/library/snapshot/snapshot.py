#!/usr/bin/env python

import datetime
import random
import sys
import time

from ansible.module_utils.basic import *

try:
    import boto3
    from botocore.exceptions import ClientError, WaiterError
except ImportError:
    print "failed=True msg='boto3 and botocore required for this module'"
    sys.exit(1)

DOCUMENTATION = '''
---
module: snapshot
short_description: Module to take snapshot of volumes for EC2/RDS with retry mechanism
options:
    type:
        description:
            - Type of Service
        choices: ['rds', 'ec2']
    instance_id:
        description:
            - Unique identifier for the service
    device_name:
        description:
            - Storage Device to back-up
    region:
        description:
            - Region of hosting
    description:
        description:
            - Snapshot Description
    max_retries:
        description
            - Max retries in case of throttling or failure
'''

EXAMPLES = '''
- name: Take snapshot of EC2 volume (root)
  snapshot:
    type: 'ec2'
    instance_id: "i-123456"
    device_name: "/dev/sda"
    region: "ap-southeast-1"
    description: "snapshot-20102017-011025"
    max_retries: 5

- name: Take snapshot of RDS
  snapshot:
    type: 'rds'
    description: "tenant-mkt-prod1-snapshot-20102017-011025"
    instance_id: "tenant-mkt-prod1"
    region: "ap-southeast-1"
    max_retries: 5
'''

MAX_RETRY_DELAY = 60.0  # max delay between retries


def get_sleep_delay(n):
    """
    Get exponential backoff delay
    Args:
        n: iteration number
    Returns:
        sleep_delay (float): random sleep delay
    """
    if n == 0:
        return 0.0
    sleep_delay = min(
        (2 ** n) + (random.randint(0, 1000) / 1000.0), MAX_RETRY_DELAY)
    return sleep_delay


def wait_for_completion(args, waiter, retry=0, wait=0):
    """
    Function to wait for instance to be in specific state
    Args:
        args (dict): Options dictionary
        waiter (Object): Boto Resource Waiter Object
        wait (int): Wait period for random sleep
        retry (int): No of retries taken.
    Returns:
        boolean: Function completed or not
    """

    max_retries = int(args.get('max_retries'))

    if retry == max_retries:
        return False

    # Exponential back-off sleep delay
    sleep_delay = get_sleep_delay(wait)
    time.sleep(sleep_delay)

    try:
        if args.get('type') == 'ec2':

            waiter.wait(
                SnapshotIds=[
                    args.get('snapshot_id')]
                # WaiterConfig={
                #     'Delay': args.get('delay'),
                #     'MaxAttempts': args.get('max_attempts')}
                    )
        else:
            # if unavailable:
            waiter.wait(DBInstanceIdentifier=args.get('instance_id'))
            # else:
            #     waiter.wait(
            #         DBInstanceIdentifier=args.get('instance_id')
            #         DBSnapshotIdentifier=args.get('snapshot_id')
            #         WaiterConfig={
            #             'Delay': args.get('delay'),
            #             'MaxAttempts': args.get('max_attempts')}
            #         )
    except ClientError as e:
        if e.response['Error']['Code'] == 'RequestLimitExceeded':
            if not wait_for_completion(args, waiter, retry + 1, wait + 1):
                return False
        else:
            raise e
    except WaiterError as e:
        if not wait_for_completion(args, waiter, retry + 1, wait + 1):
            return False

    return True


def create_snapshot(args, conn, waiter, wait=0, retry=0):
    """
    Function which takes snapshot of EC2 / RDS storage volumes.
    A random sleep delay along with max retries is added to
    prevent from AWS API Throttling
    Args:
        args (dict): Options dictionary
        conn (Object): Boto Resource Connection object
        waiter (Object): Boto Resource Waiter Object
        wait (int): Wait period for random sleep
        retry (int): No of retries taken.
    Returns:
        boolean: Function completed or not
    """

    max_retries = int(args.get('max_retries'))

    if retry == max_retries:
        return False

    # Exponential back-off sleep delay
    sleep_delay = get_sleep_delay(wait)
    time.sleep(sleep_delay)

    try:
        if args.get('type') == 'ec2':

            args['delay'] = 180
            args['max_attempts'] = 20

            snapshot = conn.create_snapshot(
                VolumeId=args['vol_id'], Description=args['description'])

            args['snapshot_id'] = snapshot['SnapshotId']

        else:

            args['delay'] = 300
            args['max_attempts'] = 40

            snapshot = conn.create_db_snapshot(
                DBSnapshotIdentifier=args.get('description'),
                DBInstanceIdentifier=args.get('instance_id'))

            args['snapshot_id'] = snapshot['DBSnapshot']['DBSnapshotIdentifier']

        # Random delay as the waiter doesn't get accurate state of instance right away.
        time.sleep(round(random.uniform(15, 20), 2))

        if not wait_for_completion(args, waiter):
            return False

    except ClientError as e:
        if e.response['Error']['Code'] == 'RequestLimitExceeded':
            if not create_snapshot(args, conn, waiter, wait + 1, retry + 1):
                return False
        elif e.response['Error']['Code'] == 'InvalidDBInstanceState':
            if not wait_for_completion(args, waiter):
                return False
        else:
            raise e

    return True


def snapshot_handler(opt, wait=0, retry=0):
    """
    Intermediate handler function to find metadata to take snapshots.
    A random sleep delay along with max retries is added to
    prevent from AWS API Throttling
    Args:
        opt (dict): Options dictionary
        wait (int): Wait period for random sleep
        retry (int): No of retries taken.
    """

    max_retries = int(opt['max_retries'])

    if retry == max_retries:
        return False, "No retries left"

    try:

        # Exponential back-off sleep delay
        sleep_delay = get_sleep_delay(wait)
        time.sleep(sleep_delay)

        if opt['type'] == 'ec2':
            if not opt['device_name']:
                return False, "Device Name is required attribute for EC2 Snapshot"

            ec2 = boto3.client('ec2', region_name=opt['region'])

            ec2_waiter = ec2.get_waiter('snapshot_completed')

            if opt.get('snap_id', None):
                if not wait_for_completion(opt, ec2_waiter):
                    return False, "No retries left"
            else:
                volume = ec2.describe_volumes(Filters=[{'Name': 'attachment.instance-id', 'Values': [
                    opt['instance_id']]}, {'Name': 'attachment.device', 'Values': [opt['device_name']]}])

                opt['description'] = "%s-%s" % (
                    opt['description'], datetime.datetime.now().strftime("%Y%m%d-%H%M%S"))

                opt['vol_id'] = volume['Volumes'][0]['VolumeId']

                if not create_snapshot(opt, ec2, ec2_waiter):
                    return False, "No retries left"

        else:
            if not opt['description']:
                return False, "Name is required attribute for RDS Snapshot"

            rds = boto3.client('rds', region_name=opt['region'])

            rds_waiter = rds.get_waiter('db_instance_available')

            if opt.get('snap_id', None):
                if not wait_for_completion(opt, rds_waiter):
                    return False, "No retries left"
            else:
                description = "%s-%s" % (
                    opt['description'], datetime.datetime.now().strftime("%Y%m%d-%H%M%S"))

                opt['description'] = description

                if not create_snapshot(opt, rds, rds_waiter):
                    return False, "No Retries Left"

    except ClientError as e:
        if e.response['Error']['Code'] == 'RequestLimitExceeded':
            snapshot_handler(opt, wait + 1, retry + 1)
        else:
            raise e

    return True, "Snapshot Completed"


def cli():
    """
    CLI
    """

    opt = dict()
    opt['type'] = 'rds'
    opt['region'] = 'ap-southeast-1'
    opt['instance_id'] = 'ac7qeprod-rt-prod2'
    opt['max_retries'] = 5
    opt['device_name'] = '/dev/xvda'
    opt['description'] = 'ac7qeprod-rt-prod2-backup'
    opt['snapshot_info'] = ""

    success, message = snapshot_handler(opt)
    if success:
        print success
    else:
        print success, message


def main():
    """
    Main Function
    """

    fields = {
        "type": {"required": True, "type": "str", "choices": ["rds", "ec2"]},
        "instance_id": {"required": True, "type": "str"},
        "device_name": {"required": False, "type": "str"},
        "region": {"required": True, "type": "str"},
        "max_retries": {"required": True, "type": "int"},
        "description": {"required": True, "type": "str"},
        "snapshot_info": {"required": False, "type": "dict"}
    }
    module = AnsibleModule(argument_spec=fields)

    opt = dict()
    opt['type'] = module.params.get('type')
    opt['region'] = module.params.get('region')
    opt['instance_id'] = module.params.get('instance_id')
    opt['max_retries'] = module.params.get('max_retries')
    opt['device_name'] = module.params.get('device_name')
    opt['description'] = module.params.get('description')

    snapshot = None
    success = False
    message = None

    if opt['type'] == 'rds':
        snap_stdout = module.params['snapshot_info'].get('stdout', "")
        if snap_stdout != "":
            snapshot = snap_stdout.split('\n')
    else:
        snapshot_results = module.params['snapshot_info'].get('results', None)
        if snapshot_results:
            for snap_info in snapshot_results:
                resource_id = snap_info['item']['item']
                if opt['instance_id'] in resource_id:
                    snapshot = filter(None, snap_info['stdout'].split('\n'))

    if snapshot and len(snapshot) > 0:
        for snap in snapshot:
            opt['snap_id'] = snap.split('\t')[0]
            snap_status = snap.split('\t')[1]
            if opt['type'] == 'ec2':
                opt['snap_vol'] = snap.split('\t')[2]
                if snap_status != 'completed':
                    success, message = snapshot_handler(opt)
                    break
            else:
                if snap_status != 'available':
                    success, message = snapshot_handler(opt)
                    break
                if snap_status == 'available':
                    success = True
                    message = "Snapshot already done in the previous run. Skipping"
                    break
    else:
        success, message = snapshot_handler(opt)

    if success:
        module.exit_json(meta=message)
    else:
        module.fail_json(meta=message)


if __name__ == "__main__":

    main()

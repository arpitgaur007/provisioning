#!/usr/bin/env python

import uuid
import datetime
import time
import hashlib
import base64
import httplib
import json
import urllib
import pprint
import time
from Crypto.PublicKey import RSA
from ansible.module_utils.basic import *

API_ENDPOINT = "https://gateway-api.omniture.com/1.0/client"

try:
    from urlparse import urlparse
except:
    from urllib.parse import urlparse

def generate_RSA(bits=2048):
    '''Generate an RSA keypair with an exponent of 65537 in PEM format

    :param bits: The key length in bits
    :rtype: private key and public key tuple
    '''
    new_key = RSA.generate(bits, e=65537)
    public_key = new_key.publickey().exportKey("PEM")
    private_key = new_key.exportKey("PEM")
    return private_key, public_key


def import_RSA(private_key):
    '''Import an RSA keypair from it's private part

    :param private_key: private key string
    :rtype: private key and public key tuple
    '''
    new_key = RSA.importKey(private_key)
    public_key = new_key.publickey().exportKey("PEM")
    private_key = new_key.exportKey("PEM")
    return private_key, public_key


class ServiceAccount():

    def __init__(self, user, secret):
        """Initialize ServiceAccount manager object

        :param endpoint: what endpoint url to use
        :param user: login of the account use to interact with the API
        :param secret: secret of the account use to interact with the API
        :rtype: ServiceAccount object instance
        """
        self.endpoint = API_ENDPOINT
        self.user = user
        self.secret = secret
        self.conn = self._connect()

    def _wsse_token(self):
        """generate a wsse token for API authentication

        :rtype: WSSE header content
        """
        # nonce is just a UUID v4
        nonce = str(uuid.uuid4())
        nonceBase64 = base64.b64encode(nonce)

        # current date should be in the following format
        now = time.strftime(
            "%Y-%m-%d %H:%M:%S z",
            datetime.datetime.utcnow().timetuple())

        # digest is a base64 encoded SHA1 of the nonce + current date + secret
        digest = base64.b64encode(
            hashlib.sha1(nonce + now + self.secret).digest())

        # assemble the WSSE header
        return "UsernameToken Username=\"%s\", PasswordDigest=\"%s\", Nonce=\"%s\", Created=\"%s\"" % (self.user, digest, nonceBase64, now)

    def _connect(self):
        """create a connexion object

        :rtype: an httplib.HTTPConnection or httplib.HTTPSConnection object
        """
        h = urlparse(self.endpoint)
        if h.scheme == 'http':
            conn = httplib.HTTPConnection(h.netloc, timeout=10)
        elif h.scheme == 'https':
            conn = httplib.HTTPSConnection(h.netloc, timeout=10)
        else:
            raise Exception('unknown protocole %s' (h.scheme))
        return conn

    def get_all_sa(self, imsorgid):
        """get all accounts of a given imsorgid

        :param imsorgid: imsorgid from which to recover the accounts
        :rtype: list of accounts for this IMSOrgID
        .. sourcecode:: python

            {
            u'clients':
            [
            {u'bypass_scope_authorization': False,
            u'client_identifier': u'ffb636b6c4-acs-monitoring',
            u'client_name': u'acs_monitoring',
            u'client_secret': u'c59a3872b4f33f9bfe71',
            u'company': u'112233445566778899AABBCCDDEEFF@AdobeOrg',
            u'description': u'',
            u'grant_type': u'jwt_bearer',
            u'id': 108,
            u'public_key': None,
            u'redirect_uri': u'',
            u'scope': u'',
            u'user_identifier': u'112233445566778899AABBCCDDEEFF@AdobeOrg',
            u'username': u''
            }
            ],
            u'success': True
            }
        """
        wsseHeader = self._wsse_token()

        data = {'company': imsorgid}
        qs = urllib.urlencode(data)

        self.conn.request("GET", "/1.0/client?" + qs,
                          headers={'X-WSSE': wsseHeader})
        r = self.conn.getresponse()
        if r.status == 403:
            raise Exception('API Access denied, wrong/missing API key?')
        if r.status != 200:
            raise Exception('Bad return code %s from the API' % str(r.status))
        return json.load(r)

    def get_sa_by_id(self, client_identifier):
        """get a specific service account by its id

        :param client_identifier: client_identifier to query
        :rtype: list of accounts matching that id
        .. sourcecode:: python

            {
            u'clients':
                [
                    {
                    u'bypass_scope_authorization': False,
                    u'client_identifier': u'aa86d74a52-acs-monitoring',
                    u'client_name': u'acs_monitoring',
                    u'client_secret': u'da75373c8e47a0e3a45e',
                    u'company': u'112233445566778899AABBCCDDEEFF@AdobeOrg',
                    u'description': u'',
                    u'grant_type': u'jwt_bearer',
                    u'id': 110,
                    u'public_key': u'LS0tLS1CRUdJTiBQVUJ...',
                    u'redirect_uri': u'',
                    u'scope': u'',
                    u'user_identifier': u'112233445566778899AABBCCDDEEFF@AdobeOrg',
                    u'username': u''
                    }
                ],
            u'success': True
            }
        """
        wsseHeader = self._wsse_token()
        data = {'client_identifier': client_identifier}
        qs = urllib.urlencode(data)
        self.conn.request("GET", "/1.0/client?" + qs,
                          headers={'X-WSSE': wsseHeader})
        r = self.conn.getresponse()
        if r.status == 403:
            raise Exception('API Access denied, wrong/missing API key?')
        if r.status != 200:
            raise Exception('Bad return code %s from the API' % str(r.status))
        return json.load(r)

    def get_sa_by_name(self, imsorgid, client_name):
        """get all account with a given <client_name> in an IMSOrgId

        :param imsorgid: imsorgid to search
        :param client_name: client_name to search
        :rtype: list of accounts matching that name
        .. sourcecode:: python

            [
                {
                    u'bypass_scope_authorization': False,
                    u'client_identifier': u'ffb636b6c4-acs-monitoring',
                    u'client_name': u'acs_monitoring',
                    u'client_secret': u'c59a3872b4f33f9bfe71',
                    u'company': u'112233445566778899AABBCCDDEEFF@AdobeOrg',
                    u'description': u'',
                    u'grant_type': u'jwt_bearer',
                    u'id': 108,
                    u'public_key': u'LS0tLS1CRUdJTiBQVUJ...',
                    u'redirect_uri': u'',
                    u'scope': u'',
                    u'user_identifier': u'112233445566778899AABBCCDDEEFF@AdobeOrg',
                    u'username': u'',
                }
            ]
        """
        clients = self.get_all_sa(imsorgid)
        ret = []
        for client in clients['clients']:
            if client['client_name'] == client_name:
                cl = self.get_sa_by_id(client['client_identifier'])
                ret += cl['clients']
        return ret

    def create_sa(self, imsorgid, rsa_pub, client_name, grant_type):
        """create an account in a given imsorgid

        :param imsorgid: IMSorgId of the account
        :param rsa_pub: public RSA key to provision
        :param client_name: name of the account to create
        :param grant_type: type of grants
        :rtype: created account
        .. sourcecode:: python

            {
                u'bypass_scope_authorization': False,
                u'client_identifier': u'7abc825d9e-acs-monitoring',
                u'client_name': u'acs_monitoring',
                u'company': u'112233445566778899AABBCCDDEEFF@AdobeOrg',
                u'description': u'',
                u'grant_type': u'jwt_bearer',
                u'id': 109,
                u'public_key': u'LS0tLS1CRUdJTiBQVUJ...',
                u'redirect_uri': u'',
                u'scope': u'',
                u'success': True,
                u'user_identifier': u'112233445566778899AABBCCDDEEFF@AdobeOrg',
                u'username': u''
            }
        """
        return self.create_raw(
            json.dumps(
                {
                    'client_name': client_name,
                    'user_identifier': imsorgid,
                    'company': imsorgid,
                    'grant_type': grant_type,
                    'public_key': base64.b64encode(rsa_pub),
                }
            )
        )

    def create_raw(self, data):
        """create an account in a given imsorgid

        :param data: json payload used to create the account
        :rtype: created account

        .. sourcecode:: python

            {
                u'bypass_scope_authorization': False,
                u'client_identifier': u'7abc825d9e-acs-monitoring',
                u'client_name': u'acs_monitoring',
                u'company': u'112233445566778899AABBCCDDEEFF@AdobeOrg',
                u'description': u'',
                u'grant_type': u'jwt_bearer',
                u'id': 109,
                u'public_key': u'LS0tLS1CRUdJTiBQVUJ...',
                u'redirect_uri': u'',
                u'scope': u'',
                u'success': True,
                u'user_identifier': u'112233445566778899AABBCCDDEEFF@AdobeOrg',
                u'username': u''
            }
        """
        wsseHeader = self._wsse_token()
        params = data
        self.conn.request("POST", "/1.0/client", body=params,
                          headers={
                          'X-WSSE': wsseHeader,
                          "Content-type": "application/json; charset=UTF-8",
                          "Accept": "text/plain"
                          })
        r = self.conn.getresponse()
        if r.status == 403:
            raise Exception('API Access denied, wrong/missing API key?')
        if r.status != 200 and r.status != 201:
            data = json.load(r)
            raise Exception('Bad return code %s from the API' % str(r.status))
        return json.load(r)

    def delete_sa(self, client_identifier):
        """delete a given account
        :param client_identifier: client_identifier of the account to delete
        :rtype: status
        .. sourcecode:: python

        {u'success': True}
        """
        wsseHeader = self._wsse_token()
        params = json.dumps({
            'client_identifier': client_identifier,
        })
        self.conn.request("DELETE", "/1.0/client", body=params,
                          headers={
                          'X-WSSE': wsseHeader,
                          "Content-type": "application/json; charset=UTF-8",
                          "Accept": "text/plain"
                          })
        r = self.conn.getresponse()
        if r.status == 403:
            raise Exception('API Access denied, wrong/missing API key?')
        if r.status != 200 and r.status != 201:
            data = json.load(r)
            raise Exception('Bad return code %s from the API' % str(r.status))
        return json.load(r)

def main():
    private_key, public_key = generate_RSA()

    fields = {
        "username": {"required": True, "type": "str"},
        "secret": {"required": True, "type": "str" },
        "environment": {"required": True, "type": "str" },
        "imsorgid": {"required": True, "type": "str" },
    }
    module = AnsibleModule(argument_spec=fields)
    ims = ServiceAccount(module.params['username'], module.params['secret'])
    r = ims.get_sa_by_name(module.params['imsorgid'], module.params['environment'])
    for sa in r:
        print "deleting %s" % sa["client_identifier"]
        ims.delete_sa (sa["client_identifier"])
    result = ims.create_sa(module.params['imsorgid'], public_key, module.params['environment'], 'jwt_bearer')

    module.exit_json(changed=False, ansible_facts=dict( \
        ims_client_identifier=result['client_identifier'], \
        ims_private_key=base64.b64encode(private_key)))


if __name__ == "__main__":
    main()

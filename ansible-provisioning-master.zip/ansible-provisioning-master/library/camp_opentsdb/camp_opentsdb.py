#!/usr/bin/env python
from ansible.module_utils.basic import *

#### None ansible implementation for IMS interaction

import uuid
import datetime
import time
import httplib
import json
import urllib

try:
    from urlparse import urlparse
except:
    from urllib.parse import urlparse
 
DOCUMENTATION = '''
module: camp_opentsdb

short_description: configure OpenTSDB monitoring in ACS

description:
    - manage Monitoring_OpenTSDB_* xtkOptions in ACS
    - /!\ this module will run the nlserver command, it requires the proper environment variables

version_added: 1.9

options:
  opentsdb_endpoint:
    description:
      - the OpenTSDB url endpoint
    required: true
  instance_name:
    description:
      - name of the ACS instance
    required: false
  state:
    description:
      - present (default) or absent
    required: false
  disable_auth:
    description:
      - disable auth
    required: false
example:

neolane_env:
  LD_LIBRARY_PATH: "/usr/local/neolane/nl7/lib"
  PWD: "/home/neolane/"
  HOME: "/home/neolane/"
  PATH: "/usr/local/neolane/nl7/bin:/usr/bin:/usr/sbin:/bin:/sbin:/usr/local/bin:/usr/local/sbin"
  LANG: "en_US.ISO-8859-15"
  LC_ALL: ""
  LC_CTYPE: ""

- name: Configure OpenTSDB
  camp_opentsdb:
    opentsdb_endpoint: "http://opentsdb"
    instance_name: 'testansible_mkt_stage1'
    #disable_auth: true
    #state: 'absent'
  environment: neolane_env
'''

import subprocess, os
import tempfile
from random import randint

def get_instance_name():
    all_conf = []
    for p in ['/usr/local/neolane/nl7/conf']:
        try:
            all_conf += os.listdir(p)
        except:
            pass
    for conf in all_conf:
        m = re.match(r'config-(?P<instance_name>.+)\.xml', conf)
        if conf != 'config-default.xml' and m:
            return m.group('instance_name')

def del_option(instance, name, env=None):
    """get option value
    :param instance: neolane instance name
    :param name: name of the xtkoption
    :param env: the environment variable used by nlserver command
    """

    # build the javascript script content
    # please note the 'ans_value: ' which is a marker for the parsing
    script_content = """
loadLibrary("/nl/core/nlserver.js");

var option_name = '%(option_name)s';

var data = REST.head.option[option_name].delete();
""" % {'option_name': name}

    # create a tmp file with the script content
    fd, script_path = tempfile.mkstemp(prefix='ansible_campaign')
    file = open(script_path, 'w')
    file.write(script_content)
    file.close()
    os.close(fd)

    if env is None:
        env = os.environ

    # launch the script and recover the stdout
    p = subprocess.Popen(['nlserver', 'javascript', '-instance:%s' % (instance), '-file', script_path], env=env, stdout=subprocess.PIPE)
    out, err = p.communicate()
    if re.match('JavaScript: failure while evaluating script', out):
        raise Exception('set option failure')
    return out, err

def get_option(instance, name, env=None):
    """get option value
    :param instance: neolane instance name
    :param name: name of the xtkoption
    :param env: the environment variable used by nlserver command
    """

    # build the javascript script content
    # please note the 'ans_value: ' which is a marker for the parsing
    script_content = """
loadLibrary("/nl/core/nlserver.js");

var option_name = '%(option_name)s';

var data = REST.head.option[option_name].get();
if(data === undefined){
    console.log('ans_value: null')
}else{
    console.log('ans_value: ' + JSON.stringify(data));
}
""" % {'option_name': name}

    # create a tmp file with the script content
    fd, script_path = tempfile.mkstemp(prefix='ansible_campaign')
    file = open(script_path, 'w')
    file.write(script_content)
    file.close()
    os.close(fd)

    if env is None:
        env = os.environ

    # launch the script and recover the stdout
    p = subprocess.Popen(['nlserver', 'javascript', '-instance:%s' % (instance), '-file', script_path], env=env, stdout=subprocess.PIPE)
    out, err = p.communicate()
    mark = False
    json_out = ''

    # we need to parse the stdout of the neolane command, there are a lot of debug and useless crap...
    for line in out.splitlines():
        if re.match(r'^[0-9][0-9]:[0-9][0-9]:[0-9][0-9] *> *ans_value:.*', line):
            line = re.sub(r'^[0-9][0-9]:[0-9][0-9]:[0-9][0-9] *> *ans_value: ', '', line)
            mark = True
        if mark:
            json_out += re.sub(r'^ *', '', line)
    # remove the tmp script
    os.remove(script_path)
    # return the properly parsed json
    ret = json.loads(json_out.decode('ISO-8859-1', 'ignore'))
    if ret:
        return ret
    else:
        return {}

def compare_option(new_data, old_data):
    ret = {'eq': True, 'diff': []}
    for i in new_data:
        new_val = new_data[i]
        old_val = old_data.get(i, None)
        if new_val != old_val:
            ret['eq'] = False
            ret['diff'].append({i: {'old': old_val, 'new': new_val}})
    return ret

def set_option(instance, data, env=None):
    """get option value
    :param instance: neolane instance name
    :param data: content of the xtkoption
    :param env: the environment variable used by nlserver command
    """

    # build the javascript script content
    # please note the 'ans_value: ' which is a marker for the parsing
    script_content = """
loadLibrary("/nl/core/nlserver.js");

var data = %(data)s;

var myOwnPut = function myOwnPut(data){
    var result = REST.head.option[data.name].get();
    if(result === undefined){
        REST.head.option.post(data);
    }else{
        REST.head.option.patch(data);
    }
};

myOwnPut(data);
""" % {'data': json.dumps(data)}

    # create a tmp file with the script content
    fd, script_path = tempfile.mkstemp(prefix='ansible_campaign')
    file = open(script_path, 'w')
    file.write(script_content)
    file.close()
    os.close(fd)
    if env is None:
        env = os.environ

    # launch the script and recover the stdout
    p = subprocess.Popen(['nlserver', 'javascript', '-instance:%s' % (instance), '-file', script_path], env=env, stdout=subprocess.PIPE)
    out, err = p.communicate()
    os.remove(script_path)
    if re.match('JavaScript: failure while evaluating script', out):
        raise Exception('set option failure')
    return out, err

def main():
    fields = {
        "instance_name": {"required": False, "type": "str"},
        "disable_auth": {"required": False, "type": "bool", "default": False},
        "opentsdb_endpoint": {"required": True, "type": "str"},
        "state": {
            "default": "present", 
            "choices": ['present', 'absent'],  
            "type": 'str' 
        },
    }
    module = AnsibleModule(argument_spec=fields, supports_check_mode=True)
    changed = False
    diff = {}

    if module.params['instance_name'] is None:
        module.params['instance_name'] = get_instance_name()

    # get the interesting xtkOptions
    #TODO, FIXME, really slowwwww....
    camp_ot_ep = get_option(
        module.params['instance_name'],
        'Monitoring_OpenTSDB_Endpoint'
        ).get('stringValue', None)

    camp_disable_auth = get_option(
        module.params['instance_name'],
        'Monitoring_OpenTSDB_Disable_Auth'
        ).get('longValue', None)

    #if module.params['state'] == 'absent'
    # if absent, just removing everything if it exists
    if module.params['state'] == 'absent':
        if camp_ot_ep is not None:
            changed = True
            diff['Monitoring_OpenTSDB_Endpoint'] = {
                'old': camp_ot_ep, 'new': None}
            if not module.check_mode:
                del_option(
                    module.params['instance_name'],
                    'Monitoring_OpenTSDB_Endpoint')

        if camp_disable_auth is not None:
            changed = True
            diff['Monitoring_OpenTSDB_Disable_Auth'] = {
                'old': camp_disable_auth, 'new': None}
            if not module.check_mode:
                del_option(
                    module.params['instance_name'],
                    'Monitoring_OpenTSDB_Disable_Auth')
        module.exit_json(changed=changed, meta=diff)

    if camp_ot_ep != module.params['opentsdb_endpoint']:
        changed = True
        diff['Monitoring_OpenTSDB_Endpoint'] = {
                'old': camp_ot_ep,
                'new': module.params['opentsdb_endpoint']
        }
        if not module.check_mode:
            set_option(module.params['instance_name'],
                       {
                'name': 'Monitoring_OpenTSDB_Endpoint',
                        'label': 'OpenTSDB Endpoint URL',
                        'dataType': 'string',
                        'stringValue': module.params['opentsdb_endpoint'],
                },
            )

    if module.params['disable_auth']:
        if camp_disable_auth != 1:
            changed = True
            diff['Monitoring_OpenTSDB_Disable_Auth'] = {
                'old': camp_disable_auth, 'new': 1}
            if not module.check_mode:
                set_option(module.params['instance_name'],
                           {
                            'name': 'Monitoring_OpenTSDB_Disable_Auth',
                            'label': 'Disable IMS Authentication',
                            'dataType': 'long',
                            'longValue': 1,
                            },
                )
    else:
        if camp_disable_auth is not None:
           changed = True
           diff['Monitoring_OpenTSDB_Disable_Auth'] = {
               'old': camp_disable_auth, 'new': None}
           if not module.check_mode:
               del_option(
                   module.params['instance_name'],
                   'Monitoring_OpenTSDB_Disable_Auth')

    module.exit_json(changed=changed, meta=diff)

if __name__ == '__main__':
    main()

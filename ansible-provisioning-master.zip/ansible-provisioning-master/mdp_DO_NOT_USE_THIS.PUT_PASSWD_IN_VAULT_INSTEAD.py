#!/usr/bin/env python2
#
#   A simple script to dump all of your credentials in a form that can be easily entered into MDP
#

import os

class Instance:
    def __init__(self, name):
        self.name = name
        self.backend = {}
        self.load_info()
        self.load_db_info()
    def load_info(self):
        cred_dir = os.path.join(camproot, self.name)
        for cred in os.listdir(cred_dir):
            with open(os.path.join(cred_dir, cred)) as f:
                self.backend[cred] = f.read().strip()
    def load_db_info(self):
        # handles old-style names; see CPGNTOOLS-40062 and CPGNTOOLS-40066
        if '_' in self.name: 
            fields = self.name.split('_')
            sep = '_'
        else: # handles newer names
            fields = self.name.split('-')
            sep = '-'
        if len(fields) < 3:
            raise Exception("An instance, {}, doesn't seem to have a name of the format <tenant_id>-(mid|mkt|rt|<whatever>)-(demo|dev|stage|prod|<whatever>)<integer>".format(self.name))
        tenant = sep.join(fields[0:-2])
        environ = fields[-2] + fields[-1]
        dbnames = [db for db in dbs if db.endswith(environ) and db.startswith(tenant)]
        if len(dbnames) == 1:
            db_dir = os.path.join(dbroot, dbnames[0])
            with open(os.path.join(db_dir, 'postgres')) as f:
                self.backend['db_user'] = f.read().strip()
        elif len(dbnames) > 1:
            raise Exception("Multiple potential matching DB password files for \"{}\": {}".format(self.name, dbnames))
        else:
            pass
#            raise Exception("No DB password files found for \"{}\"".format(self.name))
        
# note: for some reason, amhimktprod1 entries don't exist for postgres

root = os.path.join(os.environ['HOME'], 'password')
camproot = os.path.join(root, 'campaign')
dbroot= os.path.join(root, 'postgresql')

dbs = [name for name in os.listdir(dbroot)]
instances = {name : Instance(name).backend for name in os.listdir(camproot)}
for name in sorted(instances.keys()):
    for cred in instances[name]:
        print name, cred, instances[name][cred]


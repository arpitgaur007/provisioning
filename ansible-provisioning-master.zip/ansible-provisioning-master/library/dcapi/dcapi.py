#!/usr/bin/env python

import sys
if sys.version_info[0] == 2:
    from urllib import urlencode
    from urlparse import urlparse
if sys.version_info[0] >= 3:
    from urllib.parse import urlencode, urlparse
from ansible.module_utils.basic import *
import time
import jwt
import uuid
import json
import httplib
import mimetypes
import base64

IMS_ENDPOINT = "https://ims-na1.adobelogin.com"
JWT_URI = '/ims/exchange/v1/jwt'


class ServiceAccount:

    def __init__(self, user, c_id, secret, org_id, p_key):
        """Initialize ServiceAccount manager object

        :param c_id: client identifier
        :param user: login of the account use to interact with the API
        :param secret: client secret of the account use to interact with the API
        :param org_id: Organisation Id
        :param p_key: private key for Adobe IO Integration
        :rtype: ServiceAccount object instance
        """
        self.ims_endpoint = IMS_ENDPOINT
        self.user = user
        self.org_id = org_id
        self.secret = secret
        self.client_id = c_id
        self.private_key = p_key
        self.conn = self._connect()

    def _connect(self):
        """create a connexion object

        :rtype: an httplib.HTTPConnection or httplib.HTTPSConnection object
        """
        h = urlparse(self.ims_endpoint)
        if h.scheme == 'http':
            conn = httplib.HTTPConnection(h.netloc, timeout=10)
        elif h.scheme == 'https':
            conn = httplib.HTTPSConnection(h.netloc, timeout=10)
        else:
            raise Exception('unknown protocol %s' (h.scheme))
        return conn

    def get_access_token(self):
        """Exchange JWT with an access token

        :rtype: an access token
        """

        jwt_token = self.create_jwt()

        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
        }
        body_credentials = {
            "client_id": self.client_id,
            "client_secret": self.secret,
            "jwt_token": jwt_token
        }
        body = urlencode(body_credentials)

        self.conn.request("POST", JWT_URI, body=body,
                          headers=headers)
        r = self.conn.getresponse()
        if r.status == 400:
            raise Exception('API Access denied, wrong/missing API key?')
        if r.status != 200 and r.status != 201:
            raise Exception('Bad return code %s from the API' % str(r.status))

        access_token = json.loads(r.read())['access_token']
        return access_token

    def create_jwt(self):
        """Creates a signed JWT token
        :rtype: a signed JWT
        """

        expiry_time = int(time.time()) + 60 * 60 * 24

        # create payload
        payload = {
            'exp': expiry_time,
            'iss': self.org_id,
            'sub': self.user,
            'aud': IMS_ENDPOINT + "/c/" + self.client_id
        }

        scopes = ["ent_documentcloud_sdk"]

        # Add scopes to the payload
        for scope in scopes:
            payload[IMS_ENDPOINT + "/s/" + scope] = True

        # create JSON Web Token, signing it with the private key.
        jwt_token = jwt.encode(payload, self.private_key, algorithm='RS256')

        # decode bytes into string
        jwt_token = jwt_token.decode("utf-8")

        return jwt_token


class DocumentCloud:

    def __init__(self, token, dc_api_url, dc_discovery_url, dc_discovery_accept):
        """Initialize Document Cloud object"""

        self.access_token = token
        self.dc_endpoint = dc_api_url
        self.dc_discovery_accept = dc_discovery_accept
        self.dc_discovery_url = dc_discovery_url
        self.conn = self._connect()

    def _connect(self):
        """create a connexion object

        :rtype: an httplib.HTTPConnection or httplib.HTTPSConnection object
        """
        h = urlparse(self.dc_endpoint)
        if h.scheme == 'http':
            conn = httplib.HTTPConnection(h.netloc, timeout=100)
        elif h.scheme == 'https':
            conn = httplib.HTTPSConnection(h.netloc, timeout=100)
        else:
            raise Exception('unknown protocol %s' (h.scheme))
        return conn

    def get_asset_uri(self, asset_file_path):
        """
        Manage asset upload on document cloud
        :param asset_file_path: asset zip location
        :rtype json object containing asset uri
        """

        asset_details, folder_details = self.gather_discovery_data()
        folder_root_uri = self.find_root_folder_uri(folder_details)
        asset_uri = self.upload_asset(asset_details, asset_file_path, folder_root_uri)

        return asset_uri

    def delete_asset(self, asset_uri):
        """
        Manage asset deletion on document cloud
        :param asset_uri: asset uri to delete
        :rtype json object showing delete status
        """

        headers = {
            "Authorization": "Bearer " + self.access_token,
            "x-api-app-info": "ac-py-dcapi",
            "x-request-id": str(uuid.uuid4())
        }

        self.conn.request(method='DELETE', url=urlparse(asset_uri).path, headers=headers)
        r = self.conn.getresponse()
        if r.status == 401:
            raise Exception('API Access denied, wrong/missing API key?')
        if r.status != 200 and r.status != 201 and r.status != 204:
            raise Exception('Bad return code %s from the API' % str(r.status))

        result = "" 

        return result

    def upload_asset(self, asset_details, asset_file_path, folder_root_uri):
        """
        Manage asset upload on document cloud
        :param asset_file_path: asset zip location
        :param asset_details: Asset POST request details
        :param folder_root_uri: Root uri of folder where the asset will get uploaded
        :rtype json object containing asset uri
        """

        asset_path = urlparse(asset_details['uri']).path

        asset_file = open(asset_file_path, 'rb')

        form_param = '{"options":{"ignore_content_type":false,"parent_uri":"%s",' \
                     '"persistence":"permanent","on_dup_name":"auto_rename"}}' % folder_root_uri['root_uri']

        #form_param = '{"options":{"ignore_content_type":false}}'

        fields = [('parameters', form_param)]
        files = [('file', 'asset.zip', base64.b64encode(asset_file.read()))]

        content_type, body = self.create_multipart_body(fields, files)

        headers = {
            "Accept": asset_details['accept'],
            "Authorization": "Bearer " + self.access_token,
            "x-api-app-info": "ac-py-dcapi",
            "Content-type": content_type,
            "x-request-id": str(uuid.uuid4())
        }

        self.conn.request(method='POST', url=asset_path, body=body, headers=headers)
        r = self.conn.getresponse()
        if r.status == 401:
            raise Exception('API Access denied, wrong/missing API key?')
        if r.status != 200 and r.status != 201:
            raise Exception('Bad return code %s from the API' % str(r.status))

        result = json.loads(r.read())

        return result

    def create_multipart_body(self, fields, files):
        """
        Create mutipart body for POST
        :param fields: sequence of (name, value) elements for regular form fields
        :param files: sequence of (name, filename, value) elements for data to be uploaded as files
        :return: (content_type, body) ready for httplib.HTTP instance
        """

        BOUNDARY = '----------ThIs_Is_tHe_bouNdaRY_$'
        CRLF = '\r\n'
        L = []
        for (key, value) in fields:
            L.append('--' + BOUNDARY)
            L.append('Content-Type: application/vnd.adobe.dc+json;profile="https://dc-api.adobe.io/schemas/asset_upload_parameters_v1.json"')
            L.append('Content-Disposition: form-data; name="%s"' % key)
            L.append('')
            L.append(value)
        for (key, filename, value) in files:
            L.append('--' + BOUNDARY)
            L.append('Content-Type: %s' % mimetypes.guess_type(filename)[0] or 'application/octet-stream')
            L.append('Content-Disposition: form-data; name="%s"; filename="%s"' % (key, filename))
            L.append('Content-Transfer-Encoding: base64')
            L.append('')
            L.append(value)
        L.append('--' + BOUNDARY + '--')
        L.append('')
        body = CRLF.join(L)
        content_type = 'multipart/form-data; boundary=%s' % BOUNDARY
        return content_type, body

    def find_root_folder_uri(self, folder_details):
        """
        Find the folder details for asset upload
        :param: folder_details: folder GET request details
        :rtype: json object of folder details
        """

        folder_path = urlparse(folder_details['uri']).path

        headers = {
            "Accept": folder_details['accept'],
            "Authorization": "Bearer " + self.access_token,
            "x-api-app-info": "ac-py-dcapi",
            "x-request-id": str(uuid.uuid4())
        }

        self.conn.request(method='GET', url=folder_path, headers=headers)

        r = self.conn.getresponse()
        if r.status == 401:
            raise Exception('API Access denied, wrong/missing API key?')
        if r.status != 200 and r.status != 201:
            raise Exception('Bad return code %s from the API' % str(r.status))

        result = json.loads(r.read())
        return result

    def gather_discovery_data(self):
        """
        Find the asset and folder details
        :rtype: json object of asset and folder details
        """

        headers = {
            "Accept": self.dc_discovery_accept,
            "Authorization": "Bearer " + self.access_token,
            "x-api-app-info": "ac-py-dcapi",
            "x-request-id": str(uuid.uuid4())
        }

        self.conn.request("GET", self.dc_discovery_url, headers=headers)
        r = self.conn.getresponse()
        result = json.loads(r.read())
        upload = result['resources']['assets']['upload']
        folder = result['resources']['folders']['get_root']
        folder_details = dict()
        asset_details = dict()
        folder_details['uri'] = folder['uri']
        folder_details['accept'] = folder['accept']['root_v1.json']
        asset_details['uri'] = upload['uri']
        asset_details['accept'] = upload['accept']['asset_v1.json']
        asset_details['parameters'] = upload['form_data_parameters'][0]
        asset_details['file'] = upload['form_data_parameters'][1]
        return asset_details, folder_details



def main():

    fields = {
        "technical_account": {"required": True, "type": "str"},
        "client_id": {"required": True, "type": "str"},
        "client_secret": {"required": True, "type": "str"},
        "private_key": {"required": True, "type": "str"},
        "imsorgid": {"required": True, "type": "str"},
        "asset_file_path": {"required": True, "type": "str"},
        "dc_endpoint": {"required": True, "type": "str"},
        "dc_discovery_path": {"required": True, "type": "str"},
        "dc_discovery_accept": {"required": True, "type": "str"},
        "asset_uri": {"required": False, "type": "str"},
        "method": {"required": True, "type": "str", "choices": ["POST", "DELETE"]}
    }
    module = AnsibleModule(argument_spec=fields)
    ims = ServiceAccount(module.params['technical_account'], module.params['client_id'],
                         module.params['client_secret'], module.params['imsorgid'],
                         module.params['private_key'])
    access_token = ims.get_access_token()

    dc = DocumentCloud(access_token, module.params['dc_endpoint'], module.params['dc_discovery_path'],
                       module.params['dc_discovery_accept'])

    if module.params['method'] == "POST":
        result = dc.get_asset_uri(module.params['asset_file_path'])
        module.exit_json(changed=True, ansible_facts=dict(zip_asset_url=result['uri'])) 
    elif module.params['method'] == "DELETE":
        if 'asset_uri' in module.params:
            result = dc.delete_asset(module.params['asset_uri'])
        else:
            module.fail_json(msg="Asset URI is required parameter for DELETE Method")
        module.exit_json(changed=True, msg="Asset URI %s deleted" % module.params['asset_uri'])

    module.exit_json(changed=False, msg="No change")

if __name__ == "__main__":
    main()

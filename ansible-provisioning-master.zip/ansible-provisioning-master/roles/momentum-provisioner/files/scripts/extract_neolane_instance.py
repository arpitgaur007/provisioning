#! /usr/bin/python

import re
from os.path import isdir
import glob

def filter_instances(instances):
    target_instance = None
    # can't proceed if no instance exists
    if len(instances) < 1:
        raise Exception("no campaigh instances found in conf directory")
    # assume we're on a single tenant instance
    if len(instances) == 1:
        # set target to the only 1 instance on the server
        target_instance = instances[0]
    else:
        # more than 1 instance - ensure --instance param specifies a valid instance name
        raise Exception("Failed to find instance. Contant <tbehal@adobe.com>")
    return target_instance


def get_camp_instances():
    # some variables to hold things
    camp_versions = [6, 7]
    camp_version = None
    conf_path = '/usr/local/neolane/nl'
    conf_dir = None
    inst_rex = re.compile('conf\/config-([^.]+)\.xml$')
    instances = []

    # determine campaign version and config path
    for version in camp_versions:
        if isdir(conf_path + `version`):
            camp_versions = version
            conf_dir = conf_path + `version`

    # glob to find a list of XML config files
    conf_files = glob.glob(conf_dir + "/conf/" + "config-*.xml")

    # extract instance names from XML file names but skip 'default' instance
    for file in conf_files:
        match = inst_rex.search(file)
        if match:
            if match.group(1) != 'default':
                instances.append(match.group(1))

    # return a list of instance names
    return instances


if __name__ == "__main__":
    instance = filter_instances(get_camp_instances())
    print(instance)

#!/usr/bin/env python
import requests
import yaml
import sys

def whitelist(stuff):
    '''
    Check if IP is already whitelisted, if not, whitelist it.
    '''
    existing = requests.get('http://localhost/api/whitelist').json()
    existing = existing['whitelist']
    for ip, hostname in stuff.iteritems():
        if ip in existing.keys():
            print '%s already whitelisted' % ip
        else:
            print '%s NOT whitelisted' % ip
            r = requests.post("http://localhost/api/whitelist/%s" % ip, json={"hostname": hostname })

def read_yaml_file(file):
    f = open(file)
    res = yaml.load(f)
    f.close()
    return res

def main(file):
    stuff = read_yaml_file(file)
    whitelist(stuff)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print "usage: %s file.yml" % (sys.argv[0])
        sys.exit(1)
    main(sys.argv[1])

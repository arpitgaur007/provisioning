from ansible import errors

def extract_int(string):
    return int(''.join(ele for ele in string if ele.isdigit()))

class FilterModule(object):
    ''' A filter to extract numbers from a string. '''
    def filters(self):
        return {
            'extract_int' : extract_int
        }

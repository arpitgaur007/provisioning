//---------------------------------------------------------------------------
//  Display workflow info
//---------------------------------------------------------------------------
function print_wkf_info(id) {
  //  Get workflow info
  var cnx = application.getConnection();
  var stmt = cnx.query("select sinternalname,slabel,istate from xtkworkflow where iworkflowid="+id+";");
  for (var row in stmt) {
    state = parseInt(row[2]);
    switch ( state )  {
      case 11:
        state_name="Running";
	break;
      case 20:
        state_name="Stopped";
	break;
      default:
        state_name="Unknown ("+state+")";
	break;
    }

    logInfo("Workflow: "+id+"\n"+
            "   Name : "+row[0]+"\n"+
            "   Label: "+row[1]+"\n"+
            "   State: "+state_name);
  }
  cnx.dispose();
}


//---------------------------------------------------------------------------
// Cleanup workflow
//---------------------------------------------------------------------------
function stop_start_workflow(id) {
  var cnx = application.getConnection();
  var stmt = cnx.query("select istate from xtkworkflow where iworkflowid="+id+";");
  var state=0;
  for (var row in stmt) {
    state = parseInt(row[0]);
  }

  if(state != 11) {
    logInfo("Workflow not running nothing to do!");
    return;
  }

  logInfo("   Stopping workflow ....");
  var res = xtk.workflow.Stop(id);
  logInfo("   Waiting ....");
  sleep(5000);
  do {
    stmt = cnx.query("select istate from xtkworkflow where iworkflowid="+id+";");
    for (var row in stmt) {
      state = parseInt(row[0]);
    }
    sleep(5000);
    logInfo("   Waiting ....");
  } while(state != 20);

  logInfo("   Starting workflow again ....");
  res = xtk.workflow.Start(id);
  logInfo("   Wiating 10 secs to check  ....");
  sleep(10*1000);
  cnx.dispose();
}

//---------------------------------------------------------------------------
// Cleanup workflow
//---------------------------------------------------------------------------
function cleanup_workflow(id) {

  var cnx = application.getConnection()

  // Get workflow state
  var state = 0;
  var stmt = cnx.query("select sinternalname,slabel,istate from xtkworkflow where iworkflowid="+id+";");
  for (var row in stmt) {
    state = parseInt(row[2]);
  }

  if (state == 11 ) {
    stmt = cnx.query("select istatus,sactivity from xtkworkflowtask where iworkflowid="+id+"and istatus=0;");
    for (var row in stmt) {
      state = parseInt(row[2]);
    }
    if ( row[1] == "schedule") {
      logInfo("   GOOD: Workflow waiting on a scheduler");
      stop_start_workflow(id);
    } else {
      logInfo("   DO NOTHING: Workflow is not waiting on a scheduler");
    };
  } else {
      logInfo("   DO NOTHING: Workflow is not running");
  }

  logInfo("");
  cnx.dispose();

}

//---------------------------------------------------------------------------
// get workflows with most tasks
//---------------------------------------------------------------------------
function clean_workflows_with_many_tasks()
{
  var cnx = application.getConnection();

  //  list workflows by task numbers , high number are probably workflows with lots of temp data to purge
  var stmt = cnx.query(" select count(substring(tablename from E'wkf#\"[[:digit:]]+#\"%' for '#')), substring(tablename from E'wkf#\"[[:digit:]]+#\"%' for '#') as workflowid from pg_tables where tablename like 'wkf%' group by substring(tablename from E'wkf#\"[[:digit:]]+#\"%' for '#') order by count(substring(tablename from E'wkf#\"[[:digit:]]+#\"%' for '#')) desc;");

  //remove flag Keep interim etc....
  sqlExec("update xtkworkflowevent set ikeepresult=0 where ikeepresult=1; ");
  sqlExec("update xtkworkflow set mdata=replace(mdata, 'keepResult=\"true\"', 'keepResult=\"false\"') where mdata like '%keepResult=\"true\"%'");

  for (var row in stmt) {
    count      = parseInt(row[0]);
    workflowid = parseInt(row[1]);
    print_wkf_info(workflowid);
    if( count >15 ) {
      cleanup_workflow(workflowid);
    }
  }
  cnx.dispose();
}

clean_workflows_with_many_tasks();

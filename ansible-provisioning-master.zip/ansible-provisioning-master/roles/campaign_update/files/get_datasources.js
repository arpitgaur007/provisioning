var defaultDataSource = NLWS.xtkQueryDef.create({
    queryDef: {
      schema: "nms:amcDataSource",
      operation: "get",
      select: {
        node: [{
          expr: "@name",
        },{
          expr: "@dataSourceId"
        },{
          expr: "@destinationId",
        },{
          expr: "@targetResource",
        },{
          expr: "@targetSchema",
        },{
          expr: "@targetField",
        },{
          expr: "@hashAlgorithm",
        }]
      },
      where: {
        condition: [{
          expr: "@name = 'defaultDataSource'"
        }]
      }
    }
}).ExecuteQuery();
  
saveXmlFile(defaultDataSource.toXMLString(), '/tmp/defaultDataSource.xml');
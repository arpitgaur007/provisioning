var imsorgid = REST.head.option.IMS_Organization.get();
logInfo(imsorgid.stringValue);
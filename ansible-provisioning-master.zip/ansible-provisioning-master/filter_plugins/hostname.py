import types


def _get_domainname(string):
    splited_item = string.split('.')
    if len(splited_item) == 1:
        return ''
    else:
        return '.'.join(splited_item[1:])

def hostname(var):
    if isinstance(var, (list, types.GeneratorType)):
        return [item.split('.')[0] for item in list]
    if isinstance(var, basestring):
        return var.split('.')[0]

def domainname(var):
    if isinstance(var, (list, types.GeneratorType)):
        result = []
        for item in var:
            result.append(_get_domainname(item))
        return result
    if isinstance(var, basestring):
        return _get_domainname(var)


class FilterModule(object):

    def filters(self):
        return {
            'hostname': hostname,
            'domainname': domainname,
        }
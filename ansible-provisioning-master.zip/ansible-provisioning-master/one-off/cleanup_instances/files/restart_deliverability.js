//---------------------------------------------------------------------------
//  Display workflow info
//---------------------------------------------------------------------------
function print_wkf_info(id) {
  //  Get workflow info
  var cnx = application.getConnection();
  var stmt = cnx.query("select sinternalname,slabel,istate from xtkworkflow where iworkflowid="+id+";");
  for (var row in stmt) {
    state = parseInt(row[2]);
    switch ( state )  {
      case 11:
        state_name="Running";
	break;
      case 20:
        state_name="Stopped";
	break;
      default:
        state_name="Unknown ("+state+")";
	break;
    }

    logInfo("Workflow: "+id+"\n"+
            "   Name : "+row[0]+"\n"+
            "   Label: "+row[1]+"\n"+
            "   State: "+state_name);
  }
  cnx.dispose();
}


//---------------------------------------------------------------------------
// Cleanup workflow
//---------------------------------------------------------------------------
function stop_start_workflow(id) {
  var cnx = application.getConnection();
  var stmt = cnx.query("select istate from xtkworkflow where iworkflowid="+id+";");
  var state=0;
  for (var row in stmt) {
    state = parseInt(row[0]);
  }

  if(state != 11 && state != 13) {
    logInfo("Workflow not running nothing to do!");
    return;
  }

  if (state == 13) {
      logInfo("Workflow is currently in failed state");
  }

  logInfo("   Stopping workflow ....");
  var res = xtk.workflow.Stop(id);
  logInfo("   Waiting ....");
  sleep(5000);
  do {
    stmt = cnx.query("select istate from xtkworkflow where iworkflowid="+id+";");
    for (var row in stmt) {
      state = parseInt(row[0]);
    }
    sleep(5000);
    logInfo("   Waiting ....");
  } while(state != 20);

  logInfo("   Starting workflow again ....");
  res = xtk.workflow.Start(id);
  logInfo("   Wiating 10 secs to check  ....");
  sleep(10*1000);
  cnx.dispose();
}

//---------------------------------------------------------------------------
// Cleanup workflow
//---------------------------------------------------------------------------
function restart_deliverability_workflow() {

  var cnx = application.getConnection()

  // Get workflow state
  var state = 0;
  var id = 0;
  var stmt = cnx.query("select iworkflowid,sinternalname,slabel,istate from xtkworkflow where sinternalname = 'deliverabilityUpdate';");
  for (var row in stmt) {
    id = parseInt(row[0]);
    state = parseInt(row[3]);
  }

  if (state == 13 ) {
    stmt = cnx.query("select istatus,sactivity from xtkworkflowtask where iworkflowid="+id+"and istatus=0;");
    for (var row in stmt) {
      state = parseInt(row[2]);
    }
    if ( row[1] == "schedule" || row[1] == "schedule2" ) {
      logInfo("   GOOD: Workflow waiting on a scheduler. Changes.");
      stop_start_workflow(id);
    } else {
      logInfo("   DO NOTHING: Workflow is not waiting on a scheduler");
    };
  } else {
      logInfo("   DO NOTHING: Workflow is not on error. No change.");
  }

  logInfo("");
  cnx.dispose();

}

restart_deliverability_workflow();

#!/usr/bin/env python

# this should be the base class for all exceptions deliberately thrown by this library
class NeoException(Exception):
    pass

# this should be thrown when the user of this library does something wrong
class UserError(NeoException):
    pass

class NotLoggedInException(UserError):
    pass

class ClientError(NeoException):
    pass

class ServerError(NeoException):
    pass

# for the specific case where a user attempts to create an entry, but another entry with that name already exists
class DuplicateEntryException(ServerError):
    pass

# for errors specified in soap:Fault tags from the old deliverability environment
class SoapException(ServerError):
    pass

class LoginFailedException(SoapException):
    pass

# for when the call goes fine, and the response comes back without an error message, but the mix of data in the response cannot be safely collapsed into a form this library understands
class InconsistentDataException(NeoException):
    pass

class EntryNotFoundException(InconsistentDataException):
    pass


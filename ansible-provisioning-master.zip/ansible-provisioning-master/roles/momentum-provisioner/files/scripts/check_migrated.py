#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# Author - Tarun Behal
# tbehal@adobe.com
# Code logic is copied from npc package.

import glob
import os
import sys
import xml.etree.ElementTree


def Error(msg):
    try:
        sys.stderr.write("%s" % (msg))
    except IOError:
        Exit(1)


def Exit(code):
    # sys.exit() may fail (emitting warnings) in some python version if sys.stdout/sys.stderr is already closed.
    try:
        sys.stdout.flush()
    except:
        pass
    try:
        sys.stderr.flush()
    except:
        pass
    try:
        sys.exit(code)
    except:
        os._exit(code)


def Fatal(msg):
    Error("%s\n" % (msg))
    Exit(1)


def Output(msg):
    try:
        sys.stdout.write("%s" % (msg))
    except IOError:
        Exit(1)


def ParseXML():
    p6 = '/usr/local/neolane/nl6/conf/'
    p7 = '/usr/local/neolane/nl7/conf/'

    nl6 = glob.glob(p6 + '*.xml') + glob.glob(p6 + 'serverConf.d/*.xml') + glob.glob(p6 + 'config-*.d/*.xml')
    nl7 = glob.glob(p7 + '*.xml') + glob.glob(p7 + 'serverConf.d/*.xml') + glob.glob(p7 + 'config-*.d/*.xml')

    if len(nl6) == 0 and len(nl7) == 0:
        # No XML configuration file found
        Fatal("No XML configuration found for nl6 or nl7")
    elif len(nl6) > 0 and len(nl7) > 0:
        # Both nl6 and nl7 installed ?
        Fatal("Found XML configuration files both for nl6 and nl7. Sorry, this is not supported.")

    is_v7 = (len(nl7) > 0)

    # Parse all XML configuration files found, looking for IP addresses.
    # Also look for 'useMomentum' in <mta> for v7/ACS
    frelays = {}  # MTA <relay>s found: keys = IP:port, values = /path/to/cfg.xml
    use_mtum = {}  # <mta useMomentum> values. Keys = /path/to/cfg.xml, values = should be true or false
    stat_server = {}  # autostart flag values found for the <stat> line. Keys = /path/to/cfg.xml, values = should be true or false
    xmlfiles = []

    for cfg in nl6 + nl7:
        try:
            tree = xml.etree.ElementTree.parse(cfg)
        except Exception, e:
            Error('%s\n' % (e))
            continue

        root = tree.getroot()
        if root == None: continue

        for mta in root.iter('mta'):
            # Check for <mta useMomentum=...> (only for v7/ACS)
            if is_v7:
                t = mta.get('useMomentum')
                if t is not None:
                    if cfg in use_mtum:
                        Fatal("Found several <mta useMomentum=...>  in %s. This is not supported." % (cfg))
                    if t.lower() in ('true', 'false'):
                        use_mtum[cfg] = t.lower()
                    else:
                        Fatal(
                            "Found unexpected <mta useMomentum=\"%s\"> value in %s. This is not supported." % (t, cfg))
            relays = mta.findall('relay')
            if len(relays) > 1:
                Fatal("Found several <relay …> in XML file %s" % (cfg))
            elif len(relays) == 1:
                relay = relays[0]
                address = relay.attrib.get('address')
                port = relay.attrib.get('port')
                if address is None or port is None:
                    Fatal("Found invalid <relay …> in XML file %s: missing address or port" % (cfg))
                if address != '':
                    frelays['%s:%s' % (address, port)] = cfg

        for s in root.iter('stat'):
            stat_server[cfg] = s.attrib.get('autoStart')

        xmlfiles.append(cfg)

    if len(frelays) == 1:
        relay = frelays.keys()[0]
    else:
        relay = None

    return xmlfiles, is_v7, relay, use_mtum


def check_migrated():
    xmlfiles, is_v7, relay, use_mtum = ParseXML()
    if relay == '127.127.127.127:25':
        Fatal('Instance registered with momentum')
    elif relay:
        Fatal('Instance has different relay configured: {}'.format(relay))


if __name__ == "__main__":
    check_migrated()
    Exit(0)

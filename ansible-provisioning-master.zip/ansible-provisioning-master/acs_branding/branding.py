import jinja2
import argparse
import os
import shlex
import subprocess


def render_js(customer_name, sender_name, domains=[]):
    replyto_name = sender_name
    templateLoader = jinja2.FileSystemLoader(searchpath="./template")
    templateEnv = jinja2.Environment(loader=templateLoader)
    TEMPLATE_FILE = "brand.js.j2"
    template = templateEnv.get_template(TEMPLATE_FILE)

    datafile = open(os.path.join('files', 'brand.js'), 'w')
    for domain in domains:
        data = template.render(domain=domain, customer=customer_name, sender=sender_name, reply=replyto_name)
        datafile.write(data)
    datafile.close()


def run_ansible(tenant, ins_typs, env):
    host = tenant + '-' + ins_typs + '-' + env
    with open(os.path.join("inventory"), "w") as inventory:
        inventory.write(host)
    command = shlex.split("ansible-playbook --extra-vars \"tenant=%s instance_type=%s instance_env=%s\" -i inventory acs_branding.yml" % (tenant, ins_typs, env))
    try:
        p1 = subprocess.Popen(command, stdout=subprocess.PIPE)
        print(p1.communicate()[0])
    except Exception as e:
        print(e)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("tenant", help="Tenant ID")
    parser.add_argument("ins_type", help="Instance type")
    parser.add_argument("env", help="Environment Numbet Eg: stage1/prod1")
    parser.add_argument("customer", help="Customer Full Name")
    parser.add_argument("sender_name", help="Sender Name")
    parser.add_argument("domains", help="Comma seperated domains")
    args = parser.parse_args()

    domains = args.domains.split(',')

    render_js(args.customer, args.sender_name, domains)

    run_ansible(args.tenant, args.ins_type, args.env)

#!/bin/sh
dir=$(mktemp -d)
mkdir $dir/conf.d
chmod -R 777 $dir
cp -r /etc/nagios3/conf.d/*.cfg $dir/conf.d/
cp $1 $dir/conf.d/hosts.cfg
cp /etc/nagios3/commands.cfg $dir/commands.cfg
cp /etc/nagios3/nagios.cfg $dir/nagios.cfg
nagios3 -v $dir/nagios.cfg
nagios_result=$?
rm -rf $dir
exit $nagios_result
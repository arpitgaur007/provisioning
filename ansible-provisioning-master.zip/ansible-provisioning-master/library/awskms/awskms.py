#!/usr/bin/env python
"""Pythin module to create and delete AWS KMS keys"""

from ansible.module_utils.basic import *
import boto3
import json

DOCUMENTATION = '''
---
module: awskms
short_description: python script for awskms module for Ansible.
Note- We are just disabling the keys and not deleting them as they might be needed for some data recovery from snapshots etc.
'''

EXAMPLES = '''
- name: Create KMS key
  awskms:
    tenant_id: "prakharops"
    region: "ap-south-1"
    environment: "stage1"
    mode: "create"
    kms_policy_bucket_name: "campaign-kms-policy"
    kms_policy_file_name: "policy.json"
- name: Disable check from newrelic
  newrelic:
     region: "ap-south-1"
     kms_key: "5ff4de5e-e476-4080-91d3-861e5d4ffd86"
     mode: "delete"
'''


class Awskms:
    def __init__(self):
        self.response_code_map = {
            201: "Successful",
            204: "Monitor Deleted",
            400: "Bad Request",
            402: "Payment Required",
            404: "Not Found",
            429: "Rate Limit Exceeded"
        }

    def check_kms_key(self, searchingtag, value, region):
        if searchingtag == "kms_key":
            client = boto3.client('kms', region_name=region)
            try:
                payload = client.describe_key(KeyId=value)
                return True
            except Exception as e:
                return False
        elif searchingtag == "tenant_id":
            client = boto3.client('kms', region_name=region)
            try:
                marker = None
                while True:
                    if marker is None:
                        response = client.list_aliases(Limit=100)
                    else:
                        response = client.list_aliases(Limit=100, Marker=marker)
                    for alias in response['Aliases']:
                        if value in alias['AliasName']:
                            value = client.describe_key(KeyId=alias['TargetKeyId'])
                            return value['KeyMetadata']['Arn']
                    if 'NextMarker' in response:
                        marker = response["NextMarker"]
                    else:
                        return False
            except Exception as e:
                return False

    def delete_kms_key(self, encryption_key, region):
        payload = None
        client = boto3.client('kms', region_name=region)
        try:
            payload = client.disable_key(KeyId=encryption_key)
            return payload
        except Exception as e:
            return None

    def create_kms_key(self, tenant_id, region, environment, kms_policy_bucket, kms_policy_file):
        policy = None
        client = boto3.client('s3')
        response = client.get_object(Bucket=kms_policy_bucket, Key=kms_policy_file)
        policy = response['Body'].read()
        if not policy:
            return "Failed to read policy JSON"
        client = boto3.client('kms', region_name=region)
        try:
            key = client.create_key(Policy=policy, Description='Encryption key for %s' % tenant_id)
            arn = key['KeyMetadata']['Arn']
            client.create_alias(AliasName='alias/%s-%s' % (tenant_id, environment), TargetKeyId=arn)
        except Exception as e:
            return None
        return arn
    
    def enable_key_rotation(self, region, key):
        client = boto3.client('kms', region_name=region)
        try:
            response = client.enable_key_rotation(KeyId=key)
            if response['ResponseMetadata']['HTTPStatusCode'] == 200:
                return True
        except Exception as e:
            return False
        

def main_ansible_module():
    """ Entry point for ansible module """
    argument_spec = {
        'tenant_id': {'required': False, 'type': "str"},
        'region': {'required': True, 'type': "str"},
        'kms_key': {'required': False, 'type': "str"},
        'environment': {'required': False, 'type': "str"},
        'kms_policy_bucket_name': {'required': False, 'type': "str"},    ## use- campaign-kms-policy for default
        'kms_policy_file_name': {'required': False, 'type': "str"},      ## use- policy.json for default
        "mode": {"required": True, "type": "str", "choices": ['create', 'delete']}
    }
    module = AnsibleModule(argument_spec=argument_spec)
    api = Awskms()
    if module.params['mode'] == "create":
        tenant_id = module.params['tenant_id']
        environment = module.params['environment']
        alias_value = (tenant_id + "-" + environment)
        existance = api.check_kms_key("tenant_id", alias_value, module.params['region'])
        if not existance:
            key_check = api.create_kms_key(module.params['tenant_id'], module.params['region'],
                                           module.params['environment'], module.params['kms_policy_bucket_name'], module.params['kms_policy_file_name'])
            if key_check is not None:
                api.enable_key_rotation(module.params['region'], key_check)
                module.exit_json(changed=True, msg="{}".format(key_check))
            else:
                module.fail_json(msg="{}:{}".format("Error ! Failed while creating KMS keys", key_check))
        else:
            module.exit_json(changed=False, msg="{}".format(existance))

    if module.params['mode'] == "delete":
        key_check = api.delete_kms_key(module.params['kms_key'], module.params['region'])
        if key_check is not None:
            module.exit_json(changed=True,
                             msg="Disabled KMS Key")
        else:
            module.fail_json(msg="{}:{}".format("Error ! KMS key not found", key_check))


if __name__ == "__main__":
    main_ansible_module()


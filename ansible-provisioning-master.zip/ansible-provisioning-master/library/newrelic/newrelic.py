#!/usr/bin/env python
""" Python module for Newrelic Module for Ansible"""

from ansible.module_utils.basic import *
import json
import requests
import time

DOCUMENTATION = '''
---
module: newrelic
short_description: python script for newrelic module for Ansible.
'''

EXAMPLES = '''
- name: Adding production host to newrelic
  newrelic:
    api_key: "XXXXXX"
    monitor_name: "richaops-mkt-dev4-1"
    hosting: "AWS"
    check_type: SIMPLE
    frequency: 1
    uri: "https://richaops-mkt-dev4-1.camapaign.adobe.com/xtk/logon.jssp?ims=0"
    check_locations: "AWS_US_EAST_1,AWS_EU_CENTRAL_1,AWS_AP_SOUTHEAST_1"
    region: "us-west-2"
    check_status: ENABLED
    sla_threshold: 1.0
    validation_string: "logon"
    verify_ssl: False
    bypass_head_request: True
    treat_redirect_as_failure: False
    extra_labels: "{'label1':'value1', 'label2':'value2', 'label3':'value3'....,'labeln':'valueN'}"
    mode: "create"
- name: Remove check from newrelic
  newrelic:
     api_key: "XXXXXX"
     monitor_name: "richa-mkt-dev4-1"
     mode: "delete"
'''

API_URL = "https://synthetics.newrelic.com/synthetics/api/v3/monitors"
LABELS_URL = "https://synthetics.newrelic.com/synthetics/api/v1/monitors/labels"
SEARCHING_TAG = "Hostname"


def build_monitor_payload(name, check_type, frequency, uri, locations,
                          status, sla_threshold, validation_string, verify_ssl,
                          bypass_head_request, treat_redirect_as_failure):
    """building monitor payload"""
    payload = {
        "name": name,
        "type": check_type,
        "frequency": frequency,
        "uri": uri,
        "locations": locations.split(','),
        "status": status,
        "slaThreshold": sla_threshold,
        "options": {
            "validationString": validation_string,
            "verifySSL": verify_ssl,
            "bypassHEADRequest": bypass_head_request,
            "treatRedirectAsFailure": treat_redirect_as_failure
        }
    }
    return json.dumps(payload)


class Newrelic(object):
    """newrelic class"""
    url = API_URL
    labels_url = LABELS_URL

    def __init__(self, api_key):
        self.api_key = api_key
        self.headers = {'X-Api-Key': self.api_key,
                        'Content-Type': 'application/json'}
        self.headers_labels = {
            'X-Api-Key': self.api_key
        }
        self.response_code_map = {
            201: "Successful",
            204: "Monitor Deleted",
            400: "Bad Request",
            402: "Payment Required",
            404: "Not Found",
            429: "Rate Limit Exceeded"
        }

    def check_existing(self, name_label, tag):
        """Check if a monitor with the given Name label exists or not"""
        try:
            value = self.get_monitors(name_label, tag)
            if len(value) == 0:
                return False, None
            else:
                return True, value
        except LookupError as le:
            return True, None

    def get_monitors(self, name_label, tag):
        """Return the monitor_id based on the name label"""
        search_url = Newrelic.labels_url + "/" + tag + ":{}".format(name_label)
        monitors = requests.get(search_url, headers=self.headers_labels, timeout=10)
        monitors = json.loads(monitors.content)
        if monitors['count'] == 0:
            return []
        monitors = monitors['monitors']
        return monitors

    def add_monitor(self, name, check_type, frequency, uri, locations, status,
                    sla_threshold, validation_string, verify_ssl,
                    bypass_head_request, treat_redirect_as_failure, labels):
        """Add a new monitor based on the given parameters"""
        try:
            payload = build_monitor_payload(name, check_type, frequency, uri,
                                            locations, status, sla_threshold,
                                            validation_string, verify_ssl,
                                            bypass_head_request, treat_redirect_as_failure)
            post_resp = requests.post(Newrelic.url, headers=self.headers, data=payload, timeout=10)
            response_code = post_resp.status_code
            request_status = self.response_code_map[response_code]
            if response_code != 201:
                return response_code, request_status

            # Add Labels to monitor after a 1 sec pause
            time.sleep(1)
            monitor_location = post_resp.headers['Location']
            monitor_url = monitor_location + "/" + "labels"
            # iterate labels individually, NR does not support multiple label simultaneously yet
            for label in labels:
                label_string = "{}:{}".format(label, labels[label])
                label_post = requests.post(monitor_url, headers=self.headers_labels,
                                           data=label_string, timeout=15)
                response_code = label_post.status_code
                request_status = self.response_code_map[response_code]
                if response_code != 201:
                    return response_code, request_status
                time.sleep(1)
            return response_code, request_status

        except ValueError:
            return 400, "Value Error in parsing labels"

        except IndexError:
            return 400, "Index Parsing Error"

    def remove_monitor(self, monitor_id):
        """Delete all the checks for Hostname label"""
        delete_url = Newrelic.url + "/" + monitor_id
        monitor_result = requests.delete(delete_url, headers=self.headers_labels, timeout=10)
        response_code = monitor_result.status_code
        return response_code, monitor_result


def main_ansible_module():
    """ Entry point for ansible module """
    argument_spec = {
        'api_key': {'required': True, 'type': "str"},
        'monitor_name': {'required': True, 'type': "str"},
        'hosting': {'required': False, 'type': "str"},
        'check_type': {'required': False, 'default': 'SIMPLE', 'choices': ['SIMPLE', 'BROWSER']},
        'frequency': {'required': False, 'default': 5, 'type': "int",
                      'choices': [1, 5, 10, 15, 30, 60]},
        'uri': {'required': False, 'type': "str"},
        'check_locations': {'required': False,
                            'default': 'AWS_US_EAST_1,AWS_EU_WEST_1,AWS_AP_SOUTHEAST_1',
                            'type': "str"},
        'region': {'required': False, 'default': 'unknown', 'type': "str"},
        'check_status': {'required': False, 'default': 'ENABLED',
                         'choices': ['ENABLED', 'MUTED', 'DISABLED']},
        'sla_threshold': {'required': False, 'default': 1.0, 'type': "float"},
        'validation_string': {'required': False, 'type': "str"},
        'verify_ssl': {'required': False, 'default': True, 'type': "bool"},
        'bypass_head_request': {'required': False, 'default': True, 'type': "bool"},
        'treat_redirect_as_failure': {'required': False, 'default': True, 'type': "bool"},
        'extra_labels': {'required': False, 'default': {}, 'type': "dict"},
        "mode": {"required": True, "type": "str", "choices": ['create', 'delete']}
    }
    module = AnsibleModule(argument_spec=argument_spec)
    api = Newrelic(module.params['api_key'])
    if module.params['mode'] == "create":
        existing, existing_monitor = api.check_existing(module.params['monitor_name'], SEARCHING_TAG)
        if existing and existing_monitor is not None:
            module.exit_json(changed=False,
                             msg="Monitor exists not adding it again: {}".format(existing_monitor[0]['name']))

        '''extra_vars are optional can be given through ansible module and default_vars are defined below'''

        default_labels = {
            'Name': module.params['monitor_name'] + "_Ping_Check",
            'Hosting': module.params['hosting'],
            'Alerts': False,
            'Hostname': module.params['monitor_name'],
            'Region': module.params['region']
        }

        try:
            module.params['extra_labels']
        except NameError:
            labels = default_labels
        else:
            extra_labels = module.params['extra_labels']
            labels = dict(extra_labels)
            labels.update(default_labels)
            labels.update(labels)

        response_code, result_status = api.add_monitor(
            module.params['monitor_name'] + "_Ping_Check",
            module.params['check_type'],
            module.params['frequency'],
            module.params['uri'],
            module.params['check_locations'],
            module.params['check_status'],
            module.params['sla_threshold'],
            module.params['validation_string'],
            module.params['verify_ssl'],
            module.params['bypass_head_request'],
            module.params['treat_redirect_as_failure'],
            labels
        )

        if response_code == 201:
            module.exit_json(changed=True, msg="{}:{}".format(response_code, " Added Monitor Successfully"))
        else:
            module.fail_json(msg="{}:{}:{}".format("Error", response_code, result_status))

    if module.params['mode'] == "delete":
        existing, existing_monitor = api.check_existing(module.params['monitor_name'], SEARCHING_TAG)
        if existing is False and existing_monitor is None:
            module.exit_json(changed=False,
                             msg="Monitor Does Not Exists, Please Check Manually")
        monitor_list = api.get_monitors(module.params['monitor_name'], SEARCHING_TAG)
        for monitor_id in monitor_list:
            monitor_id = monitor_id['id']
            response_code, monitor_result = api.remove_monitor(monitor_id)
            if response_code != 204:
                module.exit_json(changed=True, msg="{}:{}:{}".format(response_code, monitor_result, "failed at one"))
    module.exit_json(changed=True, msg="{}".format("Deleted Monitor Successfully !!!-", ))


if __name__ == "__main__":
    main_ansible_module()

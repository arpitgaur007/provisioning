#!/usr/bin/env python

DOCUMENTATION = '''
---
module: Pingdom CRUD 
short_description: Useful for doing CRUD on pingdom.
'''

EXAMPLES = '''
- name: Create a check in pingdom 
  pingdom:
    app_key: "XXXXXX"
    auth_code: "Basic XXXX"
    hostname: "prashjai-training-mkt-prod1-1.campaign.adobe.com"
    url: "/xtk/logon.jssp?ims=0"
    rack: "ap-southeast-1"
    datacenter: "aws"
    shouldcontain: "Login"
    product_version: "v6"
    mode: "create"
    
- name: Delete a check from pingdom 
  pingdom:
    app_key: "XXXXXX"
    auth_code: "Basic XXXX"
    name: "prashjai-training-mkt-prod1-1"
    mode: "delete"
'''

import urllib2
import urllib
from ansible.module_utils.basic import *

API_URL = 'https://api.pingdom.com/api/2.0/'
fileName = ""

class Pingdom(object):

    def __init__(self, appkey=None, authcode=None):
        self.url = API_URL
        self.appkey = appkey
        self.authcode = authcode

    class RequestWithMethod(urllib2.Request):

        def __init__(self, url, data=None, headers={},
                     origin_req_host=None, unverifiable=False, http_method=None):
            urllib2.Request.__init__(
                self, url, data, headers, origin_req_host, unverifiable)
            if http_method:
                self.method = http_method

        def get_method(self):
            if self.method:
                return self.method
            return urllib2.Request.get_method(self)

    def method(self, url, method="GET", param=None):

        method_url = self.url + url
        if param:
            data = urllib.urlencode(param)
        else:
            data = None
        if method == "GET" and param:
            method_url = method_url + '?' + data
            req = self.RequestWithMethod(
                method_url, http_method=method, data=None)
        else:
            req = self.RequestWithMethod(
                method_url, http_method=method, data=data)
        req.add_header('App-Key', self.appkey)
        req.add_header('Authorization', self.authcode)
        response = urllib2.urlopen(req).read()
        response = json.loads(response)
        return response

    def modify_check(self, name, parameters={}):
        checks = self.get_checks(name)
        if not checks:
            print "No checks for %s" % name
            return
        for check in checks:
            id_ = check['id']
            response = self.method('checks/%s/' % id_, method='PUT', parameters=parameters)

    def add_check(self, host, rack, datacenter,shouldcontain,url,product_version):
        protocol = "http"
        encryption = "true"
        check_interval = 1
        tags = rack + "," + datacenter + "," + product_version
        port = 443
        sendtoemail = "true"
        contact_id = 14266258  # we can change it
        name = "%s Logon" % host.split(".")[0]
        param = {"name": name, "tags": tags, "host": host, "use_legacy_notifications": "true", "sendnotificationwhendown": 2,
                 "sendtoemail": sendtoemail, "contactids": contact_id, "url": url, "encryption": encryption, "type": protocol,
                 "shouldcontain": shouldcontain, "resolution": check_interval, "port": port}
        resp = self.method("checks", "GET")
        checks = [check for check in resp['checks'] if check['name'] == name]
        if len(checks) > 0:
            return None
        res = self.method("checks", "POST", param)
        return res

    def get_checks(self, c_name):
        resp = self.method("checks", "GET")
        checks = [check for check in resp['checks'] if check['name'] == c_name]
        return checks

    def remove_check(self, c_name):
        checks = self.get_checks(c_name)
        if len(checks) == 0:
            return "No checks found" 
        for check in checks:
            id = check['id']
            response = self.method('checks/%s/' % id, method='DELETE')
        return response


def main():

    fields = {
        "app_key": {"required": True, "type": "str" },
        "auth_code": {"required": True, "type": "str" },
        "hostname": {"required": False, "type": "str"},
        "name": {"required": False, "type": "str"},
        "url": {"required": False, "type": "str" },
        "rack": {"required": False, "type": "str" },
        "datacenter": {"required": False, "type": "str" },
        "shouldcontain": {"required": False, "type": "str" },
        "product_version": {"required": False, "type": "str" },
        "mode": {
            "required": True,
            "type": "str",
            "choices": ['create', 'delete', 'update', 'read']
        }
    }
    module = AnsibleModule(argument_spec=fields)
    api = Pingdom(module.params['app_key'], module.params['auth_code'])
    if module.params['mode'] == "create":
        result = api.add_check(module.params['hostname'], module.params['rack'], \
                               module.params['datacenter'],module.params['shouldcontain'], \
                               module.params['url'],module.params['product_version'])
        if result is None:
            module.exit_json(msg="Check already added", changed=False, meta=result)

    elif module.params['mode'] == "delete":
        check_name = module.params['name'] + " Logon"
        result = api.remove_check(check_name)
    elif module.params['mode'] == "update":
        check_name = module.params['name'] + "Logon"
        result = api.modify_check(check_name)
    elif module.params['mode'] == "read":
        check_name = module.params['name'] + "Logon"
        result = api.get_checks(check_name)

    if not result:
        module.fail_json(msg="Fail to perform %s operation." % (module.params['mode']), meta=result)
    else:
        module.exit_json(changed=False, meta=result)

if __name__ == "__main__":
    main()

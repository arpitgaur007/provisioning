#! /bin/bash
jsfile=disableDomainRuleset.js
jspath=/tmp

host=localhost

nlinstance_name=`curl -s http://$host/r/test |perl -ne 'm/instance=.([a-zA-Z-0-9-_]+).\s/ and print "$1"'`

if [ -z "${nlinstance_name}" ]
 then
 nlinstance_name=`cat /tmp/nl_instance_name.txt`
elif [ "${nlinstance_name}" == "default" ]
 then
 nlinstance_name=`cat /tmp/nl_instance_name.txt`
 fi

sudo su -l -c ". /usr/local/neolane/nl?/env.sh; COLUMNS=9999 nlserver javascript -instance:'$nlinstance_name' -file /tmp/'$jsfile'" neolane 2>/dev/null

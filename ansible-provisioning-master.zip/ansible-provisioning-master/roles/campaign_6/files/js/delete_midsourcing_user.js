var user_id = sqlGetInt("select ioperatorid from xtkoperator where sname='mid'");
xtk.session.WriteCollection(
        '<operator xtkschema="xtk:operator">' +
                '<operator _operation="delete" id="' + user_id + '"/>' +
        '</operator>'
);
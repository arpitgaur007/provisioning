#!/usr/bin/env python
import hvac
from ansible.module_utils.basic import *
import os
import requests
import sys

VAULT_API_VERSION = 'v1'

DOCUMENTATION = '''
---
module: hashicorpvault
short_description: Module to perform CRUD operations on hashicorl vault
'''

EXAMPLES = '''
  - name: Add tenant passwords to vault
    hashicorpvault:
      mode: "tenant"
      tenant: "richaos"
      instype: "mkt"
      env: "dev3"
      path: "secret/campaign/techops-secrets/mdp-test/provisioning/tenant"

  - name: Write passwords to vault
    hashicorpvault:
      mode: "write"
      data:
        admin : "adminpass"
        sftp: "sftppass"
      path: "secret/campaign/techops-secrets/mdp-test/provisioning/tenant/richaops/richaops-mkt-dev3"

  - name: Read passwords from vault
    hashicorpvault:
      mode: "read"
      path: "secret/campaign/techops-secrets/mdp-test/provisioning/tenant/richaops/richaops-mkt-dev3"

  - name: Delete passwords from vault
    hashicorpvault:
      mode: "delete"
      path: "secret/campaign/techops-secrets/mdp-test/provisioning/tenant/richaops/richaops-mkt-dev3"

  - name: Update password/s in vault
    hashicorpvault:
      mode: "update"
      data:
        admin : "newadminpass"
        sftp: "newsftppass"
      path: "secret/campaign/techops-secrets/mdp-test/provisioning/tenant/richaops/richaops-mkt-stage3"
'''


class Hashicorpvault:
    def __init__(self):
        self.vault_url = os.environ.get('VAULT_ADDR', 'https://vault.or1.adobe.net')
        if 'VAULT_TOKEN' in os.environ:
            self.token = os.environ['VAULT_TOKEN']
        else:
            print "ERROR: VAULT_TOKEN environment variable not set. Exiting."
            sys.exit(1)

        self.vault = self.auth()

    def auth(self):
        try:
            vault = hvac.Client(self.vault_url)
            vault.token = self.token
        except Exception as error:
            print "ERROR: Vault connection failed. Maybe the token is expired?", error
            sys.exit(1)

        try:
            vault.is_authenticated()
            return vault
        except Exception as error:
            print "ERROR: Vault authentication failed. Maybe the token is expired?", error
            sys.exit(1)

    def read(self, path):
        try:
            creds = self.vault.read(path)
        except Exception as error:
            return False, "Read failed! {}".format(error)

        if creds is None:
            output = "VaultKey:{} was not found".format(path)
            code = False
        else:
            output = creds['data']
            code = True
        return code, output

    def create(self, path, data):
        if not self.vault.read(path):
            try:
                url = os.path.join(self.vault_url, VAULT_API_VERSION, path)
                headers = {'content-type': 'application/json',
                           'X-Vault-Token': os.environ['VAULT_TOKEN']}
                res = requests.post(url=url, data=json.dumps(data), headers=headers, timeout=10)
                return True, "{} created".format(path)
            except Exception as error:
                return False, "Write Create failed! {}".format(error)
        else:
            return False, "Secret already exists! Use update() in order to update existing secrets."

    def delete(self, path):
        try:
            if self.vault.read(path):
                creds = self.vault.delete(path)
                output = "{} deleted".format(path)
                return True, output
            else:
                return False, "Key not found"
        except Exception as error:
            return False, "Delete failed! {}".format(error)

    def update(self, path, data):
        if self.vault.read(path):
            try:
                code, read_res = self.read(path)
                for k, v in data.iteritems():
                    read_res[k] = v
                url = os.path.join(self.vault_url, VAULT_API_VERSION, path)
                headers = {'content-type': 'application/json',
                           'X-Vault-Token': os.environ['VAULT_TOKEN']}
                res = requests.post(url=url, data=json.dumps(read_res), headers=headers, timeout=10)
                return True, "{} updated.".format(path)
            except Exception as error:
                return False, "Write (Update) failed! {}".format(error)
        else:
            return False, "Update failed. Credentials does not exists."


def get_creds(tenant_id, env_type, env_num):
    campaign_tenant_env = tenant_id + "-" + env_type + "-" + env_num
    postgresql_tenant_env = tenant_id + env_type + env_num
    root = os.path.join(os.environ['HOME'], 'password')
    camproot = os.path.join(root, 'campaign', campaign_tenant_env)
    dbroot = os.path.join(root, 'postgresql', postgresql_tenant_env)
    # To check Postgres password
    data = dict()
    try:
        filepath = os.path.join(dbroot, 'postgres')
        fileread = open(filepath, "r")
        pswd = fileread.readline()
        data['postgres'] = pswd
        fileread.close()
    except IOError as e:
        print(e)
        print("Wrong Parameter, Please check again and try.")
        exit(1)
    for name in 'internal', 'admin', 'sftp', 'tracking':
        filepath = os.path.join(camproot, name)
        fileread = open(filepath, "r")
        pswd = fileread.readline()
        data[name] = pswd
        fileread.close()
    for name in 'prod', 'mc':
        try:
            filepath = os.path.join(camproot, name)
            fileread = open(filepath, "r")
            pswd = fileread.readline()
            data[name] = pswd
            fileread.close()
        except IOError:
            pass
    return data


if __name__ == "__main__":

    argument_spec = {
        "tenant": {'required': False, 'Type': 'str'},
        "instype": {'required': False, 'Type': 'str'},
        "env": {'required': False, 'Type': 'str'},
        "path": {'required': True, 'Type': 'str'},
        "data": {'required': False, 'Type': 'dict'},
        "mode": {'required': True, 'Type': 'str'}
    }
    module = AnsibleModule(argument_spec=argument_spec)
    vaultcrud = Hashicorpvault()

    if module.params['mode'] == 'tenant':
        if module.params['tenant'] and module.params['instype'] and module.params['env'] and module.params['path']:
            try:
                path = os.path.join(module.params['path'], module.params['tenant'],
                                    module.params['tenant'] + '-' + module.params['instype'] + '-' + module.params[
                                        'env'])
                data = get_creds(module.params['tenant'], module.params['instype'], module.params['env'])
                msg = vaultcrud.create(path, dict(data))
                if msg[0]:
                    module.exit_json(changed=True, msg=msg[1])
                else:
                    module.exit_json(changed=False, msg=msg[1])
            except Exception as e:
                module.fail_json(changed=False, msg=e)
        else:
            module.fail_json(changed=False, msg="Following params are required: tenant, instype, env, path")

    if module.params['mode'] == 'write':
        if module.params['path'] and module.params['data']:
            data = dict(module.params['data'])
            msg = vaultcrud.create(module.params['path'], data)
            if msg[0]:
                module.exit_json(changed=True, msg=msg[1])
            else:
                module.exit_json(changed=False, msg=msg[1])
        else:
            module.fail_json(changed=False, msg="Following params are required: data, path")

    if module.params['mode'] == 'read':
        msg = vaultcrud.read(module.params['path'])
        if msg[0]:
            module.exit_json(changed=True, msg=msg[1])
        else:
            module.fail_json(changed=False, msg=msg[1])

    if module.params['mode'] == 'update':
        if module.params['path'] and module.params['data']:
            data = dict(module.params['data'])
            msg = vaultcrud.update(module.params['path'], data)
            if msg[0]:
                module.exit_json(changed=True, msg=msg[1])
            else:
                module.fail_json(changed=False, msg=msg[1])
        else:
            module.fail_json(changed=False, msg="Following params are required: data, path")

    if module.params['mode'] == 'delete':
        msg = vaultcrud.delete(module.params['path'])
        if msg[0]:
            module.exit_json(changed=True, msg=msg[1])
        else:
            module.fail_json(changed=False, msg=msg[1])
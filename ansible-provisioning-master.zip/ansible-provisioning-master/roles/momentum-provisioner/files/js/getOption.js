var opt = application.arg;
var val = getOption(opt);
if (val)
  val = val.trim();

logInfo("option_val=" + val);

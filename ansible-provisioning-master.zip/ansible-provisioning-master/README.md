Adobe Campaign TechOps Ansible playbooks
=====================

This repository contains a handful of playbooks related to putting Adobe Campaign in production, it also contains playbooks to put services supporting the product in production.

Two virtualizations are actively supported and maintained:
- Amazon EC2
- OpenVZ
 
That being said, the core of the playbooks is perfectly useable on any kind of virtualization but with no guarantee.

Requirements
====================
Python 2.7
Java Development Kit
pip install -r requirements.txt

Scope
=====================
These playbooks are directly created for use for Adobe Campaign Tech Ops, as such they may contain services that you do not require.

Secret management
=====================
Confidential variables and files are kept securely in vault files, requiring the use of a vault password to function, which is obviously not shareable. It will take trial and errors to find the variables and override them.

Pull requests
=====================
Feel free to create separate branches and to create pull requests out of them. We review them quite often.

Handling ca-central-1
=====================

Our Ansible version is completely obsolete, it doesn't handle the ca-central-1 region.

Long term we should really think of updating but this will have huge impacts.

In the mean time, the quick and dirty solution is to manually patch Ansible in the virtualenv.

The fix is not complex, it's a matter of adding ```'ca-central-1'``` in a few "AWS_REGIONS" lists.

The 3 files to modify are:

lib/python2.7/site-packages/ansible/module_utils/ec2.py:
```diff
--- python2.7/site-packages/ansible/module_utils/ec2.py	2017-12-15 10:58:35.585387596 +0100
+++ python2.7/site-packages/ansible/module_utils/ec2.py	2017-12-15 11:00:44.646825191 +0100
@@ -39,6 +39,7 @@
     'cn-north-1',
     'eu-west-1',
     'eu-central-1',
+    'ca-central-1',
     'sa-east-1',
     'us-east-1',
     'us-west-1',
```
lib/python2.7/site-packages/ansible/modules/core/cloud/amazon/ec2_ami_search.py
```diff
--- python2.7/site-packages/ansible/modules/core/cloud/amazon/ec2_ami_search.py	2017-12-15 11:07:12.199138157 +0100
+++ python2.7/site-packages/ansible/modules/core/cloud/amazon/ec2_ami_search.py	2017-12-15 11:07:22.326937419 +0100
@@ -91,6 +91,7 @@
                'ap-southeast-1',
                'ap-southeast-2',
                'eu-central-1',
+               'ca-central-1',
                'eu-west-1',
                'sa-east-1',
                'us-east-1',
```

lib/python2.7/site-packages/ansible/modules/core/cloud/amazon/ec2_facts.py
```diff
--- python2.7/site-packages/ansible/modules/core/cloud/amazon/ec2_facts.py	2017-12-15 10:07:35.949318286 +0100
+++ python2.7/site-packages/ansible/modules/core/cloud/amazon/ec2_facts.py	2017-12-15 11:03:21.635710022 +0100
@@ -64,6 +64,7 @@
                    'ap-southeast-1',
                    'ap-southeast-2',
                    'eu-central-1',
+                   'ca-central-1',
                    'eu-west-1',
                    'sa-east-1',
                    'us-east-1',
```

It would have been nice to just be able to override the ansible code, but it requires a newer version of ansible to...

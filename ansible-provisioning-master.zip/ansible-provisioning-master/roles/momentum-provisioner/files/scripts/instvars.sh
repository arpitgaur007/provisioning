#!/bin/bash
host=$1
opt=$2

INSTANCE=`curl -s http://$host/r/test |perl -ne 'm/instance=.([a-zA-Z-0-9-_]+).\s/ and print "$1"'`
BUILD=`curl -s http://$host/r/test |perl -ne 'm/build=.([0-9]+).\s/ and print "$1"'`
CAMP_VERSION=""

if [ $BUILD -gt 5000 ]; then
  CAMP_VERSION=5
fi
if [ $BUILD -gt 6000 ]; then
  CAMP_VERSION=6
fi
if [ $BUILD -gt 10000 ]; then
  CAMP_VERSION=7
fi

echo ${!opt}

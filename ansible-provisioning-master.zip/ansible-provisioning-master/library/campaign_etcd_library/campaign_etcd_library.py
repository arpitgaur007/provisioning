#!/usr/bin/env python
DOCUMENTATION = '''
---
module: Manage ETCd with ansible
short_description: Used to perform (create/read/delete) operations on the campaign etcd key-value store using ansible
'''
EXAMPLES = '''
- name: Set flag for decomission to a node in etcd
  campaign_etcd_library:
    region: "ap-southeast-1"
    tenantid: "prashjai-training"
    environment: "stage1"
'''
from ansible.errors import AnsibleError
import os
import datetime
from datetime import timedelta
from ansible.module_utils.basic import *
try:
    import etcd
    from campaign_lib.custom_etcd import CampaignEtcd, ClientException, ServerException
    HAS_PYTHON_ETCD = True
except:
    HAS_PYTHON_ETCD = False
try:
    import json
except ImportError:
    import simplejson as json
CACHE_VALID_FOR = timedelta(minutes=1)
class CampaignEtcdLibrary():
    def __init__(self, basedir=None, **kwargs):
        self.basedir = basedir
        if os.getenv('ETCD_WORK_DIR') is not None:
            self.work_dir = os.environ['ETCD_WORK_DIR']
        else:
            self.work_dir = os.path.expanduser('~')
    def read(self, terms, inject=None, **kwargs):
        if not HAS_PYTHON_ETCD:
            raise AnsibleError('python-etcd and campaign-library are required for etcd read.')
        recurse = kwargs.get('recursive', False)
        if isinstance(terms, basestring):
            terms = [ terms ]
        ret = []
        for term in terms:
            etcd = CampaignEtcd(work_dir=self.work_dir)
            try:
                if recurse:
                    result = json.dumps(etcd.read(term, sorted=True, recursive=True).to_tree())
                    ret.append(result)
                else:
                    result = etcd.read(term, sorted=True).value
                    ret.append(result)
            except ClientException:
                ret.append("")
            except ServerException:
                ret.append("")
        return ret
    def write(self, key, value, ttl=None, inject=None, **kwargs):
        if not HAS_PYTHON_ETCD:
            raise AnsibleError('python-etcd and campaign-library are required for etcd write.')
        ret = []
        etcd = CampaignEtcd(work_dir=self.work_dir)
        try:
            result = etcd.write(key,value)
            ret.append(result)
        except ClientException:
            ret.append("")
        except ServerException:
            ret.append("")
        return ret
    def delete(self, terms, inject=None, **kwargs):
        if not HAS_PYTHON_ETCD:
            raise AnsibleError('python-etcd and campaign-library are required for etcd delete.')
        recurse = kwargs.get('recursive', False)
        if isinstance(terms, basestring):
            terms = [ terms ]
        ret = []
        for term in terms:
            etcd = CampaignEtcd(work_dir=self.work_dir)
            print dir(etcd)
            try:
                if recurse:
                    result = etcd.delete(term, sorted=True, recursive=True, dir=True)
                    ret.append(result)
                else:
                    result = etcd.delete(term, sorted=True, dir=True)
                    ret.append(result)
            except ClientException:
                ret.append("")
            except ServerException:
                ret.append("")
        return ret
    def decomission(self, path, key, value, ttl=None, inject=None, **kwargs):
        return_text = self.write(key, value)
        result = self.delete(path + "/servers/app/", recursive=True)
        return return_text
def main():
    devnull = open('/dev/null', 'w')
    oldstdout_fno = os.dup(sys.stdout.fileno())
    os.dup2(devnull.fileno(), 1)
    fields = {
        "region": {"required": False, "type": "str"},
        "tenantid": {"required": False, "type": "str"},
        "environment": {"required": False, "type": "str"},
        "recursive": {"required": False, "type": "bool", "default": True},
        "path": {"required": False, "type": "str"},
        "key": {"required": False, "type": "str"},
        "value": {"required": False, "type": "str"},
        "func": {"required": False, "type": "str", "default": "decomission", "choices": ['decomission', 'reportsharing', 'write', 'read']},
        "mode": {"required": False, "type": "str", "default": "W", "choices": ['W', 'R', 'D']},
        "value": {"required": False, "type": "str"}
    }
    module = AnsibleModule(argument_spec=fields)
    api = CampaignEtcdLibrary()
    if module.params['func'] == 'decomission':
        path = "datacenters/" + module.params['region'] + "/campaign/" + module.params['tenantid'] + "/environments/" + module.params['environment']
        endpoint = path + "/decomission_date"
        result = api.decomission(path, endpoint, "%s" %(datetime.date.today().strftime("%B %d, %Y")))
        os.dup2(oldstdout_fno, 1)
        if not result:
            module.fail_json(msg="Failure to set the decomission flag on the key %s" % path)
        else:
            result = {'changed': result[0].newKey, 'output': 'Tenant Environment marked for decomissioning'}
            module.exit_json(**result)
    elif module.params['func'] == 'write':
        if module.params['key'] and module.params['value']:
            endpoint = module.params['path'] + module.params['key']
            result = api.write(endpoint, module.params['value'])
            os.dup2(oldstdout_fno, 1)
            if not result:
                module.fail_json(msg="Failed to set %s at %s" % (module.params['key'], module.params['path']))
            else:
                result = {'changed': result[0].newKey, 'output': '%s written at path %s' % (module.params['key'], module.params['path'])}
                module.exit_json(**result)
        else:
            module.fail_json(msg="Key or Value is missing")
    elif module.params['func'] == 'read':
        if module.params['key']:
            endpoint = module.params['path'] + module.params['key']
            result = api.read(endpoint)
            os.dup2(oldstdout_fno, 1)
            if not result:
                module.exit_json({'changed': False, msg: "%s not present at %s" % (module.params['key'], module.params['path'])})
            else:
                result = {'changed': False, 'output': result[0]}
                module.exit_json(**result)
        else:
            module.fail_json(msg="Key is missing")
    elif module.params['func'] == 'reportsharing':
        path = "integration/reportsharing/asset/"
        endpoint = path + module.params['region']
        if module.params['mode'] == 'D':
            result = api.delete(endpoint)
        else:
            result = api.write(endpoint,module.params['value'])
        os.dup2(oldstdout_fno, 1)
        if not result:
            module.fail_json(msg="Failed to set asset uri at %s" % endpoint)
        else:
            result = {'changed': result[0].newKey, 'output': 'Asset uri set'}
            module.exit_json(**result)
if __name__ == '__main__':
    main()

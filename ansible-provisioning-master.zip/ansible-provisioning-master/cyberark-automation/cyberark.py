import httplib
import json
import os
import sys
import argparse
from cyberark_receive import *

neo_safe = "NEO"
cyberark_url = "cyberark.corp.adobe.com"
cyberark_pass = 'jeYp0HAUBsEWmumFjc3ZuSQ4h6jxw5YfNcvM756pHyXLszqtTRzD9gbP3UvAs62jz3l7/Pqovp+QhDfmbjQPU74rq4ZeBftb3H4j2iGKXMdxYTqK7IXPjjSXTbqsGgSam6k/bVc1K/s9A4ik85e+ZbRoSvHkpBhkU8lZu9vpYbB3TSUSY+S26JVyXmqjReaDqn29vgZO3PSKlhBJndePv4MtJecXn0eOcrQdop7fBYY1tVuZuj4KryDCdreqv8kZnpcanBnjCwpO0c2zhoOE9jvJD0TgGMki3GB45Osp97XjpRiL6HoZwT++YL+ZzyfBzvlduRVCazFFPVD0CzstYA=='



def getCAAuthToken(password):
    conn = httplib.HTTPSConnection("cyberark.corp.adobe.com")

    payload = "{\r\n  \"username\":\"campaignneo\",\r\n  \"password\":\"" + password + "\"," \
              "\r\n  \"useRadiusAuthentication\":\"false\",\r\n  \"connectionNumber\":\"1\"\r\n}\r\n "

    headers = {
        'content-type': "application/json",
        'cache-control': "no-cache",
    }

    conn.request("POST", "/PasswordVault/WebServices/auth/Cyberark/CyberArkAuthenticationService.svc/Logon", payload,
                 headers)

    res = conn.getresponse()
    data = res.read()

    authorization_header = data.decode("utf-8")
    authorization_header = json.loads(authorization_header)
    return authorization_header


def addAccount(server_type, instance_name, password, customer_name, product, cyberarkpassword):
    conn = httplib.HTTPSConnection(cyberark_url)
    autherization_token = getCAAuthToken(cyberarkpassword)
    headers = {
        'content-type': "application/json",
        'cache-control': "no-cache",
        'authorization': autherization_token['CyberArkLogonResult']
    }

    account = dict()
    payload = {"safe": "NEO", "address": server_type, "platformID": "NEO_WEB", "deviceType": "Database",
               "username": "admin", "password": password, "serviceName": instance_name,
               "accountName": customer_name + "_" + instance_name + "_" + product + "_" + "OTHER"}

    account["account"] = payload

    conn.request("POST", "/PasswordVault/WebServices/PIMServices.svc/Account", json.dumps(account), headers)

    res = conn.getresponse()
    if int(res.status) == 200 or int(res.status) == 201:
        data = res.read()
    else:
        sys.exit(1)
    print data.decode("utf-8")


def getAccount(keyword):
    conn = httplib.HTTPSConnection("cyberark.corp.adobe.com")
    autherization_token = getCAAuthToken()
    headers = {
        'content-type': "application/json",
        'cache-control': "no-cache",
        'authorization': autherization_token
    }
    conn.request("GET", "/PasswordVault/WebServices/PIMServices.svc/Accounts?keywords=" + keyword + "&safe=NEO",
                 headers=headers)
    res = conn.getresponse()
    data = res.read()
    print(data.decode("utf-8"))


if __name__ == "__main__":

    data = recieve_sqs_data()
    if data:
        try:
            addAccount(data['servername'], data['instancename'], data['password'], data['customer'], data['product'], datadecrypt('private_key.pem', cyberark_pass))
            print("Record added into cyberark")
        except Exception as e:
            print(e)
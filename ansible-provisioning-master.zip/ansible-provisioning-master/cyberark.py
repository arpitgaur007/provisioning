import httplib
import json
import os
import argparse

neo_safe = "NEO"


def getCAAuthToken(password):
    conn = httplib.HTTPSConnection("cyberark.corp.adobe.com")

    payload = "{\r\n  \"username\":\"APPOPS\",\r\n  \"password\":\"" + password + "\"," \
              "\r\n  \"useRadiusAuthentication\":\"false\",\r\n  \"connectionNumber\":\"1\"\r\n}\r\n "

    headers = {
        'content-type': "application/json",
        'cache-control': "no-cache",
    }

    conn.request("POST", "/PasswordVault/WebServices/auth/Cyberark/CyberArkAuthenticationService.svc/Logon", payload,
                 headers)

    res = conn.getresponse()
    data = res.read()

    authorization_header = data.decode("utf-8")
    authorization_header = json.loads(authorization_header)
    return authorization_header


def addAccount(server_type, instance_name, password, customer_name, product, cyberarkpassword):
    conn = httplib.HTTPSConnection("cyberark.corp.adobe.com")
    autherization_token = getCAAuthToken(cyberarkpassword)
    headers = {
        'content-type': "application/json",
        'cache-control': "no-cache",
        'authorization': autherization_token['CyberArkLogonResult']
    }

    account = {}
    payload = {}
    payload["safe"] = "NEO"
    payload["address"] = server_type
    payload["platformID"] = "NEO_WEB"
    payload["deviceType"] = "Database"
    payload["username"] = "admin"
    payload["password"] = password
    payload["serviceName"] = instance_name
    payload["accountName"] = customer_name + "_" + instance_name + "_" + product + "_" + "OTHER"
    account["account"] = payload

    #print(account)
    conn.request("POST", "/PasswordVault/WebServices/PIMServices.svc/Account", json.dumps(account), headers)

    res = conn.getresponse()
    data = res.read()
    print data.decode("utf-8")


def getAccount(keyword):
    conn = httplib.HTTPSConnection("cyberark.corp.adobe.com")
    autherization_token = getCAAuthToken()
    headers = {
        'content-type': "application/json",
        'cache-control': "no-cache",
        'authorization': autherization_token
    }
    conn.request("GET", "/PasswordVault/WebServices/PIMServices.svc/Accounts?keywords=" + keyword + "&safe=NEO",
                 headers=headers)
    res = conn.getresponse()
    data = res.read()
    print(data.decode("utf-8"))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("servertype", help="Server URL")
    parser.add_argument("instancename", help="Instance name. Eg tenant_mkt_prod1")
    parser.add_argument("password", help="Admin password")
    parser.add_argument("customer", help="Customer Full Name")
    parser.add_argument("product", help="Product Version. Eg:- V6/V7")
    parser.add_argument("cyberarkpassword", help="Cyberarch internal user password")
    args = parser.parse_args()

    addAccount(args.servertype, args.instancename, args.password, args.customer, args.product, args.cyberarkpassword)

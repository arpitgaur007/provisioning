#!/usr/bin/python
import boto3
import argparse


def tags_map(volume_type, cost_center, environment, nl_version, owner, customer, eccid, name):
    if volume_type == "sftp":
        name = name + "-SFTP"
        vol_class = "Appserver SFTP Volume"
    elif volume_type == "root":
        name = name + "-ROOT"
        vol_class = "Appserver Root Volume"
    return [
        {
            'Key': 'Adobe:Class',
            'Value': vol_class
        },
        {
            'Key': 'Adobe:CostCenter',
            'Value': cost_center
        },
        {
            'Key': 'Adobe:Environment',
            'Value': environment
        },
        {
            'Key': 'Adobe:NLVersion',
            'Value': nl_version
        },
        {
            'Key': 'Adobe:Owner',
            'Value': owner
        },
        {
            'Key': 'Customer',
            'Value': customer
        },
        {
            'Key': 'Customer:ECCID',
            'Value': eccid
        },
        {
            'Key': 'Name',
            'Value': name
        },
        {
            'Key': 'Adobe:Autobackups',
            'Value': 'Enabled'
        }
    ]


def get_instance_tags(tags):
    for tag in tags:
        if tag['Key'] == 'Name':
            name = tag['Value']
        elif tag['Key'] == 'Adobe:CostCenter':
            cost_center = tag['Value']
        elif tag['Key'] == 'Adobe:Owner':
            owner = tag['Value']
        elif tag['Key'] == 'Customer':
            customer = tag['Value']
        elif tag['Key'] == 'Adobe:NLVersion':
            nl_version = tag['Value']
        elif tag['Key'] == 'Customer:ECCID':
            eccid = tag['Value']
        elif tag['Key'] == 'Adobe:Environment':
            environment = tag['Value']
    return name, cost_center, owner, customer, nl_version, eccid, environment


def update_tags(volume_id, tags, region):
    ec2_client = boto3.client('ec2', region_name=region)
    ec2_client.create_tags(
        DryRun=False,
        Resources=[volume_id, ],
        Tags=tags
    )


def main(instance_ids, region):
    instance_ids = instance_ids.split(",")
    for instance in instance_ids:
        ec2_client = boto3.client('ec2', region_name=region)
        response = ec2_client.describe_instances(
            InstanceIds=[
                instance,
            ],
            DryRun=False,
        )
        name, cost_center, owner, customer, nl_version, eccid, environment = get_instance_tags(
            response['Reservations'][0]['Instances'][0]['Tags'])
        for volume_id in response['Reservations'][0]['Instances'][0]['BlockDeviceMappings']:
            if volume_id['DeviceName'] == '/dev/xvda' or volume_id['DeviceName'] == '/dev/nvme0n1':
                tags = tags_map('root', cost_center, environment, nl_version, owner, customer, eccid, name)
                update_tags(volume_id['Ebs']['VolumeId'], tags, region)
            elif volume_id['DeviceName'] == '/dev/xvdf' or volume_id['DeviceName'] == '/dev/nvme0n1p1':
                tags = tags_map('sftp', cost_center, environment, nl_version, owner, customer, eccid, name)
                update_tags(volume_id['Ebs']['VolumeId'], tags, region)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("Instance_id_list", type=str, help="List of instance ids provisioned")
    parser.add_argument("Region", type=str, help="AWS Region in which instances are provisioned.")
    args = parser.parse_args()
    main(args.Instance_id_list, args.Region)


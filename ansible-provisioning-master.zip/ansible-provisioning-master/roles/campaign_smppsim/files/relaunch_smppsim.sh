#!/bin/sh

#get the port
port=$(grep ^SMPP_PORT= "SMPPSim/conf/smppsim.props" | cut -d '=' -f 2)

#kill the process if needed
pid=$(netstat -anp | grep LISTEN | grep $port | awk '{print $7}' | cut -d '/' -f 1)
if [ -n "$pid" ]
then
	kill $pid
	sleep 10
fi

#start the process
cd SMPPSim
nohup java -Djava.net.preferIPv4Stack=true -Djava.util.logging.config.file=conf/logging.properties -jar smppsim.jar conf/smppsim.props &>smppsim.log
cd ../..

loadLibrary("/nl/core/nlserver.js");

// Fetch brandings
var brandings = REST.head.branding.json.get().content;

var result = true;
logInfo('');
for(var i = 0 ; i < brandings.length; i++) {
  var branding = brandings[i];
  var mirrorPageServerUrl = branding.mirrorPageServerUrl;
  var serverUrl = branding.serverUrl;
  var trackingServerUrl = branding.trackingServerUrl;

  result &= check('mirrorPageServerUrl', mirrorPageServerUrl);
  result &= check('serverUrl', serverUrl);
  result &= check('trackingServerUrl', trackingServerUrl);
}

logInfo('');
if(result) {
  logInfo("Can proceed with upgrade");
} else {
  logError("WARNING Need to fix branding before upgrade");
}

function check(name, value) {
  var result = checkSpace(name, value);
  checkAdobeCom(name, value);
  return result;
}

function checkSpace(name, value) {
  if (value.indexOf(' ') != -1) {
    logInfo("Url for " + name + " contains forbidden space character : '" + value + "'");
    return false;
  }
  return true;
}

function checkAdobeCom(name, value) {
  if (value.indexOf('.adobe.com') != -1) {
    logInfo("Url for " + name + " contains .adobe.com : '" + value + "'");
  }
}

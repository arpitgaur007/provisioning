'''
Command Execution Example:
python decomission/decomission.py "customer=richaops instance_env=dev2 ec2_region=eu-west-1 instance_type=mkt account=campaign-ops
ec2_security_group=production packages_type=old"
'''


from campaign_lib.custom_etcd import CampaignEtcd
import subprocess
import os
import sys
import boto3
from sys import argv
from collections import OrderedDict




def get_domains(tenant, region, env):
    domains = list()
    api = CampaignEtcd()
    path = "datacenters/" + region + "/campaign/" + tenant + "/environments/" + env + "/domains"
    result = api.read(path)._children
    for item in result:
        domains.append(str(item['key'].split('/')[8]))
    return domains


def get_domains_ids(domains):
    client = boto3.client('route53')
    Marker_flag = True
    marker = None
    domain_id = list()
    while (True):
        if marker == None:
            response = client.list_hosted_zones(MaxItems="100")
        else:
            response = client.list_hosted_zones(MaxItems="100", Marker=marker)
        for domain in domains:
            for item in response['HostedZones']:
                if domain in item['Name']:
                    domain_id.append(item['Id'].split('/')[2])
                    continue
        if 'NextMarker' in response:
            marker = response['NextMarker']
        else:
            break
    return domain_id


def getawsregions():
    regions = list()

    ec2 = boto3.client('ec2')
    response = ec2.describe_regions()
    for region in response['Regions']:
        regions.append(region['RegionName'])
    return regions


def delete_hosted_domains(domain_ids):
    client = boto3.client('route53')

    for domain_id in domain_ids:
        response = client.delete_hosted_zone(Id='%s' % domain_id)
        print response


def ansible_decomission_job(**kwargs):
    path = os.path.join(os.environ['HOME'], 'ansible-provisioning', 'decomission', 'ansible_decomission.sh')
    valid_region = getawsregions()
    args = [path, argv[1], kwargs['customer'], kwargs['instance_env']]

    # Loop to check valid args
    for arg in kwargs:
        if check_meta(arg):
            if check_meta(kwargs[arg]):
                pass
            else:
                print("No special characters are allowed into arguments")
                sys.exit(1)
        else:
            print("No special characters are allowed into arguments")
            sys.exit(1)

    # Loop to check valid region

    if kwargs['ec2_region'] not in valid_region:
        print("Valid region not provided")
        sys.exit(1)

    returncode = subprocess.call(args)
    if returncode != 0:
        print("Command failed with exit code %d" % returncode)
        sys.exit(1)


def check_meta(str):
    meta = ['<', '>', '>>', '<<', '*', '?', '[', ']', '`', '$', '|', ';', '&', '(', ')', '#', '\\']
    for metachar in meta:
        if metachar in str:
            return False
    return True


# Function to collect pre and post decomission ec2 instances #

def aws_ec2(geo, tenant_id, env, ins_type):
    filters = [{
        'Name': 'tag:Name',
        'Values': [tenant_id + "-" + ins_type + "-" + env + "*"]
    }]
    client = boto3.client('ec2', region_name=geo)
    output = client.describe_instances(Filters=filters)
    i = 0
    ec2_data = []
    for reservation in output["Reservations"]:
        for instance in reservation["Instances"]:
            for tags in instance["Tags"]:
                if tags["Key"] == "Name":
                    #                    sys.stdout.write(tags["Value"] + ' ')
                    ins_name = tags["Value"]
            #            print instance["InstanceType"]
            ec2_data.append(
                {'Name': ins_name, 'InstanceType': instance["InstanceType"], 'InstanceID': instance["InstanceId"],
                 'State': instance['State']['Name']})
    return ec2_data


# Function to decomission addon ec2 instances #

def decomission_addon_ec2(instanceIds, region):
    client = boto3.client('ec2', region_name=region)

    for instid in instanceIds:
        instid_list = list()
        instid_list.append(instid)
        filters = [{
            'Name': 'attachment.device',
            'Values': ['/dev/xvda']},
            {'Name': 'attachment.instance-id',
             'Values': instid_list
             }]
        response = client.describe_volumes(Filters=filters)
        snap_ids = list()
        waiter = client.get_waiter('snapshot_completed')
        for vol in response['Volumes']:
            Tag = [
                {'ResourceType': 'instance',
                 'Tags': [
                     {'Key': 'Name',
                      'Value': 'Decomissioning Snapshot'}
                 ]
                 }
            ]
            response_snap = client.create_snapshot(VolumeId=vol['VolumeId'], Description='Decomissioning')
            result = response_snap['SnapshotId']
            snap_ids.append(response_snap['SnapshotId'])
            client.create_tags(
                Resources=[result], Tags=[
                    {'Key': 'Name', 'Value': 'Decomissioning Snapshot'},
                ]
            )
    waiter.wait(SnapshotIds=snap_ids)
    print("Snapshot completed")
    response = client.terminate_instances(InstanceIds=instanceIds)
    return response


if __name__ == "__main__":

    args_dic = OrderedDict()
    for arg in argv[1].split():
        data = arg.split("=")
        args_dic[data[0]] = data[1]

    # Function call to get associated domains #
    try:
        domains = get_domains(args_dic['customer'], args_dic['ec2_region'], args_dic['instance_env'])
    except Exception as e:
        domains = list()

    # Function call to get associated domain ids from route53 #
    if len(domains) > 0:
        domain_ids = get_domains_ids(domains)

        # Function call to delete domain zones from route53 #

        delete_hosted_domains(domain_ids)

    # Ansible call to start decomissioning the envirinment #
    ansible_decomission_job(**args_dic)

    # Checking whether any addon EC2 instance is still running and decomission it as well #

    addon_ec2 = aws_ec2(args_dic['ec2_region'], args_dic['customer'], args_dic['instance_env'], args_dic['instance_type'])

    if len(addon_ec2) > 0:
        instance_id_list = list()
        for instance in addon_ec2:
            if instance['State'] == 'running':
                instance_id_list.append(instance['InstanceID'])

    if len(instance_id_list) > 0:
        decomission_addon_ec2(instance_id_list, args_dic['ec2_region'])

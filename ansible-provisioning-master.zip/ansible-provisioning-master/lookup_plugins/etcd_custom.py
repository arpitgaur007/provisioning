from ansible import utils
from ansible.errors import AnsibleError
import os
import fcntl
import time
import shelve
import datetime
from datetime import timedelta

try:
    import etcd
    from campaign_lib.custom_etcd import CampaignEtcd, ClientException, ServerException
    HAS_PYTHON_ETCD = True
except:
    HAS_PYTHON_ETCD = False

try:
    import json
except ImportError:
    import simplejson as json

CACHE_VALID_FOR = timedelta(minutes=1)

from ansible.module_utils.urls import open_url

class LookupModule(object):

    def __init__(self, basedir=None, **kwargs):
        self.basedir = basedir
        if os.getenv('ETCD_WORK_DIR') is not None:
            self.work_dir = os.environ['ETCD_WORK_DIR']
        else:
            self.work_dir = os.path.expanduser('~')
        self.lock_file = os.path.join(self.work_dir, '.etcd.shelve.bdb.lock')
        self.lock_file_fd = None

    def _lock_file(self):
        """Create a lock file to gain exclusive access to the cache DB"""
        try:
            self.lock_file_fd = os.open(self.lock_file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC)
            fcntl.flock(self.lock_file_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except IOError as e:
            if self.lock_file_fd:
                os.close(self.lock_file_fd)
                self.lock_file_fd = None
            return False
        return True

    def _release_lock(self):
        """Release the lock file of the cache DB"""
        try:
            fcntl.flock(self.lock_file_fd, fcntl.LOCK_UN)
            os.close(self.lock_file_fd)
            os.remove(self.lock_file)
            return True
        except:
            return False

    def _aquire_lock(self):
        """Acquire the lock file for the cache DB, wait until the lock is acquired (timeout = 10 minutes)"""
        counter = 0
        while not self._lock_file():
            time.sleep(0.1)
            counter += 1
            # timeout for 10 minutes
            if counter >= 6000:
                raise AnsibleError('Timeout, failed to acquire "%s" lock on ETCD cache file' % self.lock_file)

    def run(self, terms, inject=None, **kwargs):
        if not HAS_PYTHON_ETCD:
            raise AnsibleError('python-etcd and campaign-library are required for etcd_custom lookup.')
        #terms = utils.listify_lookup_plugin_terms(terms, self.basedir, inject)
        recurse = kwargs.get('recursive', False)
        if isinstance(terms, basestring):
            terms = [ terms ]
        self._aquire_lock()
        cache = shelve.open('%s/.etcd.shelve.bdb' % self.work_dir)
        ret = []
        for term in terms:
            encoded_term = term.encode("utf-8")
            found_in_cache = False
            result = None
            if cache.has_key(encoded_term):
                cached_result_value = cache[encoded_term]['value']
                cached_result_exp = cache[encoded_term]['exp']
                if cached_result_exp >= datetime.datetime.utcnow():
                    ret.append(cached_result_value)
                    found_in_cache = True
                else:
                    del cache[encoded_term]
            if found_in_cache == False:
                etcd = CampaignEtcd(work_dir=self.work_dir)
                try:
                    if recurse:
                        result = json.dumps(etcd.read(term, sorted=True, recursive=True).to_tree())
                        ret.append(result)
                        cache[encoded_term] = {'value': result, 'exp': datetime.datetime.utcnow() + CACHE_VALID_FOR }
                    else:
                        result = etcd.read(term, sorted=True).value
                        ret.append(result)
                        cache[encoded_term] = {'value': result, 'exp': datetime.datetime.utcnow() + CACHE_VALID_FOR }
                except ClientException:
                    ret.append("")
                    cache[encoded_term] = {'value': "", 'exp': datetime.datetime.utcnow() + CACHE_VALID_FOR }
                except ServerException:
                    ret.append("")
        cache.close()
        self._release_lock()
        return ret

#test = LookupModule()
#test.run('/datacenters')

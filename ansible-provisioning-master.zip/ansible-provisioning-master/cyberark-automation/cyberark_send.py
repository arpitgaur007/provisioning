import boto3
import argparse
from Crypto.PublicKey import RSA
import base64
import sys
import os

public_key_path = "public_key.pem"

def dataencrypt(keypath, message):

    with open(keypath, 'r') as file:
        public_key = file.read()
    file.close()

    key = RSA.importKey(public_key)

    encdata = base64.b64encode(key.encrypt(message, 32)[0])

    return encdata



def send_sqs_data(instancename, server, password, product, customer):
    sqs = boto3.client('sqs', region_name='ap-south-1')

    queue_url = 'https://sqs.ap-south-1.amazonaws.com/483013340174/cyberarkdata'



    # Send message to SQS queue
    response = sqs.send_message(
        QueueUrl=queue_url,
        DelaySeconds=0,
        MessageAttributes={
            'servername': {
                'DataType': 'String',
                'StringValue': dataencrypt(public_key_path, server)
            },
            'instancename': {
                'DataType': 'String',
                'StringValue': dataencrypt(public_key_path, instancename)
            },
            'password': {
                'DataType': 'String',
                'StringValue': dataencrypt(public_key_path, password)
            },
            'product': {
                'DataType': 'String',
                'StringValue': dataencrypt(public_key_path, product)
            },
            'customer': {
                'DataType': 'String',
                'StringValue': dataencrypt(public_key_path, customer)
            }
        },
        MessageBody=('Customer Provisioned Data')
    )

    print(response['MessageId'])


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("servertype", help="Server URL")
    parser.add_argument("instancename", help="Instance name. Eg tenant_mkt_prod1")
    parser.add_argument("customer", help="Customer Full Name")
    parser.add_argument("product", help="Product Version. Eg:- V6/V7")
    args = parser.parse_args()

    instance_data = args.instancename.split('_')

    try:
        path = os.path.join(os.environ['HOME'],'password','campaign')
        f = open(path + '/{}-{}-{}/admin'.format(instance_data[0], instance_data[1], instance_data[2]), 'r')
        password = f.readline().rstrip()
    except Exception as e:
        print(e)
        sys.exit(1)

    send_sqs_data(args.instancename, args.servertype, password, args.product, args.customer)

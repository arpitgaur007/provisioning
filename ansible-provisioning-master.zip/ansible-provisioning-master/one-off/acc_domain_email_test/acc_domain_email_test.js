//Specify the argument as domain/recipient

var selectDeliveryId = "select iDeliveryId from NmsDelivery WHERE slabel = $(sz) and \
                        iDeleteStatus = 0 order by tscreated desc";
var selectRecipientId = "select iRecipientId from NmsRecipient WHERE sEmail = $(sz) order by \
                         tscreated desc";

function getDeliveryId(name) {
  var deliveryId = sqlGetDouble(selectDeliveryId, name);
  return deliveryId;
}

function deleteDelivery(deliveryId) {
  logInfo("Deleting delivery #" + deliveryId);
  NLWS.xtkSession.Write({'delivery' : {'id': deliveryId, 
                                       '_operation': 'delete',  
                                       '_ignoreDeleteStatus': 'true', 
                                       'xtkschema': 'nms:delivery'
                        }});
}

function createDelivery(domain, user) {
  var pkg = DOMDocument.load("DeliveryPackage.xml");
  pkg.getElementsByTagName("recipient")[1].setAttribute("_cs", user);
  pkg.getElementsByTagName("tmp")[0].setAttribute("_cs", user);
  pkg.getElementsByTagName("senderAddress")[0].childNodes[0].nodeValue = "no-reply@" + domain;
  pkg.getElementsByTagName("deliveryTarget")[0].setAttribute("serialization", "'Destinataire" + 
                          "'" + user + "'");
  pkg.getElementsByTagName("targetPart")[0].setAttribute("computedLabel", "Query: Destinataire" + 
                          "'" + user + "'");
  pkg.getElementsByTagName("targetPart")[0].setAttribute("label", "Destinataire " + "'" + user + 
                          "'");
  pkg.getElementsByTagName("condition")[0].setAttribute("expr", "@email= " + "'" + user + "'");
  var builder = new DOMDocument("builder");
  var p = builder.importNode(pkg.root, true);
  p.$buildNumber = "*";
  builder.root.appendChild(p);
  NLWS.xtkBuilder.InstallPackage(builder);
}

function createRecipient(firstName, email) {
  NLWS.xtkSession.Write({'recipient': {'xtkschema': 'nms:recipient',
                                       'firstName': firstName,
                                       'email': email,
                                       'folder': {'_operation': 'none', 'name': 'nmsRootRecipient'}
                         }});
}

function deleteRecipientIfExists(email) {
  var recipientId = sqlGetDouble(selectRecipientId, email)
  if( recipientId != 0 ) {
    logInfo("Deleting recipient #" + recipientId)
    NLWS.xtkSession.Write({'recipient': {'xtkschema': 'nms:recipient', 
                                         '_operation': 'delete', 
                                         id: recipientId
                          }});
  }
}

var args = application.arg;
if (args == '' || args.search('/') == -1)
{
  logError("Specify arguments in the format domain/recipent");
}
args = args.split("/");
var domain = args[0];
var user = args[1];
if (domain == '')
{
  logError("Missing domain in argument");
}
else if (user == '')
{
  logError("Missing recipient in argument");
}

deleteRecipientIfExists(user);
createRecipient('Domain Delegation', user);

var deliveryId = getDeliveryId('Test delivery');
if (deliveryId != 0)
  deleteDelivery(deliveryId);

createDelivery(domain, user);
deliveryId = getDeliveryId('Test delivery');

var delivery = nms.delivery.get(deliveryId);
//State code:95 represents successful delivery
if (delivery.state !== 95) {
    nms.delivery.PrepareFromId(deliveryId);
    nms.delivery.Play(deliveryId);
}

var startTime = Date.now();
while (nms.delivery.get(deliveryId).state !== 95 && (Date.now()-startTime) < 60000) {
    sleep(100);
    logInfo("Current state is " + nms.delivery.get(deliveryId).state)
}

deleteDelivery(deliveryId); 
deleteRecipientIfExists(user); 

#!/bin/bash

# region is mandatory
regions=(ap-northeast-1 ap-southeast-1 ap-southeast-2 eu-central-1 eu-west-1 sa-east-1 us-east-1 us-west-1 us-west-2)

if [[ -z $1 ]]; then
  echo "Usage: $0 <region> <instance> <orgid>"
  echo "instance & orgid are optional"
  exit 1
else
  if [[ ${regions[@]} =~ (^| )$1($| ) ]]; then
    region=$1
  else
    echo "ERROR: $1 is not a valid region"
    echo "valid values: ${regions[@]}"
    exit 1
  fi
fi
# identify nagios server and timezone for this region
case $region in
  ap-northeast-1) #nagios_server="nagios-ap-northeast-1.campaign-demo.adobe.com"
                  timezone="Asia/Tokyo"
                  repository_url="http://ftp.jp.debian.org/debian"
                  ;;
  ap-southeast-1) #nagios_server="nagios-ap-southeast-1.campaign-demo.adobe.com"
                  timezone="Asia/Kuala_Lumpur"
                  repository_url="http://ftp.hk.debian.org/debian"
                  ;;
  ap-southeast-2) #nagios_server="nagios-ap-southeast-2.campaign-demo.adobe.com"
                  timezone="Australia/Brisbane"
                  repository_url="http://ftp.au.debian.org/debian"
                  ;;
  eu-central-1)   #nagios_server="nagios-eu-central-1.campaign-demo.adobe.com"
                  timezone="Europe/Berlin"
                  repository_url="http://ftp.de.debian.org/debian"
                  ;;
  eu-west-1)      #nagios_server="nagios-eu-west-1.campaign-demo.adobe.com"
                  timezone="Europe/Paris"
                  repository_url="http://ftp.ie.debian.org/debian"
                  ;;
  sa-east-1)      timezoze="America/Sao_Paulo"
                  repository_url="ftp.br.debian.org/debian/"
                  ;;
  us-east-1)      #nagios_server="nagios-us-east-1.campaign-demo.adobe.com"
                  timezone="America/New_York"
                  repository_url="http://ftp.us.debian.org/debian"
                  ;;
  us-west-1)      timezone="America/Los_Angeles"
                  repository_url="http://ftp.us.debian.org/debian"
                  ;;
  us-west-2)      timezone="America/Los_Angeles"
                  repository_url="http://ftp.us.debian.org/debian"
                  ;;
esac

# in case of resetting an instance only tenantid is required and we will use existing instance profile
if [[ -n $2 && -z $3 ]]; then
  reset="y"
  tenantid="$2"
# if instance name and orgid is given, no need to check AWS inventory
elif [[ -n $2 && -n $3 ]]; then
  tenantid="$2"
  orgid="$3"
  customer_fullname=`grep "^${tenantid}," inventory/ags-demo/demo_inventory | awk -F',' '{ print $2 }'`
  if [[ -z $customer_fullname ]]; then
    customer_fullname="$2"
  fi
else
  # cleanup any temp files
  if [[ -f /tmp/$$ ]]; then
    rm -f /tmp/$$
  fi

  # get a list of all the instances which have tag 'Customer'
  for reg in ap-northeast-1 ap-southeast-1 ap-southeast-2 eu-central-1 eu-west-1 sa-east-1 us-east-1 us-west-1 us-west-2
  do
    aws ec2 describe-instances --query 'Reservations[].Instances[].[Tags[?Key==`Customer`].Value[]]' --output text --region $reg --filters "Name=instance-state-name,Values=pending,running,stopping,stopped"
  done > /tmp/$$

  # Check which one is available next
  for i in `seq -f "CPADemo%g" 1 1000`
  do
    if (( `grep -c "^$i$" /tmp/$$` == 0 )); then
      name=$i
      break
    fi
  done

  if [[ -n $name ]]; then
    tenantid=`echo $name | tr '[:upper:]' '[:lower:]'`
  else
    echo "ERROR: Cannot calculate next tenant id from AWS API"
    exit 1
  fi

  customer_fullname=`grep "^${tenantid}," inventory/ags-demo/demo_inventory | awk -F',' '{ print $2 }'`
  if [[ -z $customer_fullname ]]; then
    echo "ERROR: instance name not found in cpademo inventory file"
    echo "Please get more tenantId/IMS Org id created and add them in inventory file"
    exit 1
  fi

  orgid=`grep "^${tenantid}," inventory/ags-demo/demo_inventory | awk -F',' '{ print $3 }'`
  if [[ ! "$orgid" =~ "@AdobeOrg" ]]; then
    echo "ERROR: orgid missing for $name in cpademo inventory file"
    exit 1
  fi
fi

# create a profile when it is not a case of reset
if [[ -z $reset ]]; then
  echo "region :  $region"
  echo "tenantid: $tenantid"
  echo "name : $customer_fullname"
  echo "imsorgid : $orgid"
  ansible-playbook one-off/create_instance_profile.yml -i inventory/localhost --extra-vars "customer=$tenantid region=$region customer_fullname=$customer_fullname orgid=$orgid timezone=$timezone repository_url=$repository_url"
fi

ansible-playbook playbooks/ec2/acs/mkt/deploy_ec2_acs_mkt_dev.yml -i inventory/localhost --extra-vars "@vars/aws/ags-demo/${region}/${tenantid}.yml" --vault-password-file ~/.vault_password.txt

filter='{"Name":"tag:Name","Values":["'$tenantid'-mkt-dev1-1"]}'
ip=`aws ec2 describe-instances --region $region --filter '{"Name":"instance-state-name","Values":["running"]}' $filter --query 'Reservations[*].Instances[*].PublicIpAddress' --output text`
ssh -o StrictHostKeyChecking=no -T $ip <<EOSSH
sed -i -e '/IPAffinity name/{n;N;N;N;d}' /usr/local/neolane/nl7/conf/config-${tenantid}_mkt_dev1.xml
sed -i -e '/IPAffinity name/a <IP address="0.0.0.0" heloHost="ip0.neolane.net" publicId="1" weight="1"/>' /usr/local/neolane/nl7/conf/config-${tenantid}_mkt_dev1.xml
dpkg -r nlproxy-controller
service nlserver7 restart
EOSSH

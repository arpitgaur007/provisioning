var args = application.arg
var cuid = args.split(',')[0]
setOption('DmRendering_cuid', cuid) 
